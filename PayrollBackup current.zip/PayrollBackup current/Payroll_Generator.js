// ==============================
// 💰 PAYROLL GENERATOR (ENTERPRISE FINAL)
// ==============================
function createNextMonthPayroll() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const template = ss.getSheetByName(CONFIG.SHEETS.PAYROLL_TEMPLATE);
    const employeeSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const deptSheet = ss.getSheetByName(CONFIG.SHEETS.DEPARTMENT_ORDER);

    if (!template || !employeeSheet || !deptSheet) {
      throw new Error("Required sheets missing.");
    }

    // ==============================
    // 📅 PAYROLL MONTH (FIXED)
    // ==============================
    const today = new Date();

    // 👉 CURRENT MONTH PAYROLL (clear logic)
    const payrollDate = new Date(today.getFullYear(), today.getMonth(), 1);

    const monthName = payrollDate.toLocaleString('default', { month: 'long' });
    const year = payrollDate.getFullYear();
    const sheetName = `${monthName} ${year}`;

    // ==============================
    // 🚫 PREVENT DUPLICATE
    // ==============================
    const existingSheet = ss.getSheetByName(sheetName);
    if (existingSheet) {
      ss.setActiveSheet(existingSheet);
      SpreadsheetApp.getUi().alert(sheetName + " already exists.");
      return;
    }

    const newSheet = ss.insertSheet(sheetName);

    const totalCols = template.getLastColumn();

    // ==============================
    // 🎯 HEADER
    // ==============================
    newSheet.getRange(1,1)
      .setValue("Town Hospitals Payroll - " + sheetName);

    newSheet.getRange(1,1,1,totalCols)
      .merge()
      .setHorizontalAlignment("center")
      .setFontSize(16)
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT);

    const headers = template.getRange(1,1,1,totalCols).getValues();
    newSheet.getRange(2,1,1,totalCols).setValues(headers);

    newSheet.setFrozenRows(2);
    newSheet.setFrozenColumns(4);

    // ==============================
    // 📂 DEPARTMENT ORDER
    // ==============================
    const deptLastRow = deptSheet.getLastRow();

    const deptOrder = deptLastRow > 1
      ? deptSheet.getRange(2,1,deptLastRow-1,1).getValues().flat().filter(String)
      : [];

    // ==============================
    // 📊 MASTER DATA SAFE READ
    // ==============================
    const empLastRow = employeeSheet.getLastRow();

    const empData = empLastRow > 1
      ? employeeSheet.getRange(2,1,empLastRow-1,employeeSheet.getLastColumn()).getValues()
      : [];

    if (!empData.length) {
      SpreadsheetApp.getUi().alert("No employee data found.");
      return;
    }

    const empIdCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.EMP_ID);
    const firstCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.FIRST_NAME);
    const lastCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.LAST_NAME);
    const deptCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.DEPARTMENT);
    const salaryCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.SALARY);
    const statusCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.STATUS);
    const leftCol = getColumnIndex(employeeSheet, CONFIG.MASTER_COLUMNS.LEFT_DATE);

    const deptMap = {};

    empData.forEach(emp => {

      try {

        const empId = emp[empIdCol - 1];
        const first = emp[firstCol - 1];
        const last = emp[lastCol - 1];
        const dept = emp[deptCol - 1];
        const salary = emp[salaryCol - 1];
        const status = emp[statusCol - 1];
        const leftDate = emp[leftCol - 1];

        if (!empId || !first || !dept) return;

        let include = false;

        if (
          status === CONFIG.STATUS.ACTIVE ||
          status === CONFIG.STATUS.PROBATION
        ) {
          include = true;
        }

        if (leftDate) {

          const left = new Date(leftDate);

          if (!isNaN(left)) {

            if (
              left.getMonth() === payrollDate.getMonth() &&
              left.getFullYear() === payrollDate.getFullYear()
            ) {
              include = true;
            }

          }
        }

        if (!include) return;

        if (!deptMap[dept]) deptMap[dept] = [];

        const row = new Array(totalCols).fill("");

        row[CONFIG.COLUMNS.EMP_ID - 1] = empId;
        row[CONFIG.COLUMNS.NAME - 1] = (last + " " + first).toUpperCase();
        row[CONFIG.COLUMNS.DEPARTMENT - 1] = dept;
        row[CONFIG.COLUMNS.MONTHLY_SALARY - 1] = salary;
        row[CONFIG.COLUMNS.STATUS - 1] = CONFIG.PAYMENT_STATUS.PENDING;

        deptMap[dept].push(row);

      } catch (innerErr) {}

    });

    // ==============================
    // 🔽 SORT
    // ==============================
    Object.keys(deptMap).forEach(dept => {
      deptMap[dept].sort((a,b) => a[1].localeCompare(b[1]));
    });

    // ==============================
    // 🧾 BUILD FINAL DATA
    // ==============================
    const finalRows = [];

    deptOrder.forEach(dept => {

      if (deptMap[dept]) {

        const deptRow = new Array(totalCols).fill("");
        deptRow[1] = dept.toUpperCase();

        finalRows.push(deptRow);

        deptMap[dept].forEach(emp => finalRows.push(emp));
      }

    });

    if (finalRows.length) {
      newSheet.getRange(3,1,finalRows.length,totalCols).setValues(finalRows);
    }

    // ==============================
    // 🎨 BATCH STYLING
    // ==============================
    const bgMatrix = finalRows.map(row =>
      row[0] ? new Array(totalCols).fill("#ffffff")
             : new Array(totalCols).fill(CONFIG.COLORS.DEPT_ROW)
    );

    if (bgMatrix.length) {
      newSheet.getRange(3,1,bgMatrix.length,totalCols).setBackgrounds(bgMatrix);
    }

    // ==============================
    // 🔽 DATA VALIDATION (BATCH)
    // ==============================
    const rule = SpreadsheetApp.newDataValidation()
      .requireValueInList(CONFIG.VALIDATION.PAYMENT_STATUS, true)
      .build();

    finalRows.forEach((row,i) => {
      if (row[0]) {
        newSheet.getRange(i+3, CONFIG.COLUMNS.STATUS).setDataValidation(rule);
      }
    });

    newSheet.autoResizeColumns(1,totalCols);

    // ==============================
    // 🔒 DESIGN + PROTECTION
    // ==============================
    applyPremiumDesign(newSheet);
    protectPayrollSheet(newSheet);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYROLL_GENERATED",
      sheetName,
      Session.getEffectiveUser().getEmail()
    );

    ss.toast("Payroll created: " + sheetName, "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("Error: " + err.message);
    throw err;

  }

}