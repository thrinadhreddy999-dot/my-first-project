function fixAllProbationDates() {

  const sheet = SpreadsheetApp.getActiveSpreadsheet()
    .getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);

  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return;

  const dojCol = getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.DOJ);
  const probationCol = getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.PROBATION);

  const data = sheet.getRange(2,1,lastRow-1,sheet.getLastColumn()).getValues();

  const output = [];

  for (let i = 0; i < data.length; i++) {

    const doj = data[i][dojCol - 1];
    const probation = data[i][probationCol - 1];

    if (doj && !probation) {

      const pDate = new Date(doj);

      if (!isNaN(pDate)) {
        pDate.setMonth(pDate.getMonth() + 3);
        output.push([pDate]);
      } else {
        output.push([probation]);
      }

    } else {
      output.push([probation]);
    }

  }

  sheet.getRange(2, probationCol, output.length, 1).setValues(output);

  Logger.log("All probation dates fixed successfully");

}