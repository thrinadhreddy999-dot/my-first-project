function processEmployeeForm(data) {

  const lock = LockService.getScriptLock();

  try {

    lock.waitLock(10000);

    if (!data) throw new Error("No data received");

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const details = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);
    const history = ss.getSheetByName(CONFIG.SHEETS.EMPLOYMENT_HISTORY);

    if (!master || !details || !history) {
      throw new Error("Required sheets missing");
    }

    // ==============================
    // 🧹 CLEAN + VALIDATE
    // ==============================
    const mobile = String(data.mobile || "").replace(/\D/g, "");
    const first = String(data.first || "").trim().toUpperCase();
    const last = String(data.last || "").trim().toUpperCase();
    const dept = String(data.department || "").trim();
    const designation = String(data.designation || "").trim();
    const salary = Number(data.salary);

    if (!/^[6-9]\d{9}$/.test(mobile)) {
      throw new Error("Invalid mobile number");
    }

    if (!first || !dept || !designation || !salary || salary <= 0) {
      throw new Error("Invalid input data");
    }

    // DOJ mandatory
    if (!data.doj) throw new Error("DOJ is required");

    const doj = new Date(data.doj);
    if (isNaN(doj)) throw new Error("Invalid DOJ");

    const mode = data.mode || "NEW";

    // ==============================
    // 🔍 FIND EXISTING
    // ==============================
    const mobileCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.MOBILE);
    const empIdCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.EMP_ID);

    const detailsData = details.getLastRow() > 1
      ? details.getRange(2,1,details.getLastRow()-1,details.getLastColumn()).getValues()
      : [];

    let empId = "";

    for (let i=0;i<detailsData.length;i++){
      if (String(detailsData[i][mobileCol-1]).replace(/\D/g,"") === mobile){
        empId = detailsData[i][empIdCol-1];
        break;
      }
    }

    // ==============================
    // 🆕 CREATE
    // ==============================
    if (!empId) {

      empId = generateEmployeeId();

      master.appendRow([
        empId, first, last, dept, designation,
        CONFIG.DEFAULTS.EMPLOYMENT_TYPE,
        salary,
        CONFIG.DEFAULTS.SALARY_TYPE,
        doj,
        "",
        CONFIG.STATUS.ACTIVE,
        "", "", "", ""
      ]);

      const newRow = new Array(details.getLastColumn()).fill("");
      newRow[empIdCol-1] = empId;
      newRow[mobileCol-1] = mobile;

      details.appendRow(newRow);

      history.appendRow([
        empId, doj, "", CONFIG.STATUS.ACTIVE, "New Joining", ""
      ]);

      logAction("EMPLOYEE_CREATED", empId, Session.getEffectiveUser().getEmail());
    }

    // ==============================
    // 🔄 UPDATE / REJOIN
    // ==============================
    else {

      const masterData = master.getDataRange().getValues();

      for (let i=1;i<masterData.length;i++){

        if (masterData[i][0] === empId){

          const row = i + 1;

          const statusCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.STATUS);
          const dojCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.DOJ);
          const salaryCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.SALARY);

          const currentStatus = master.getRange(row, statusCol).getValue();

          if (mode === "UPDATE") {

            master.getRange(row, getColumnIndex(master, CONFIG.MASTER_COLUMNS.FIRST_NAME)).setValue(first);
            master.getRange(row, getColumnIndex(master, CONFIG.MASTER_COLUMNS.LAST_NAME)).setValue(last);
            master.getRange(row, getColumnIndex(master, CONFIG.MASTER_COLUMNS.DEPARTMENT)).setValue(dept);
            master.getRange(row, getColumnIndex(master, CONFIG.MASTER_COLUMNS.DESIGNATION)).setValue(designation);
            master.getRange(row, salaryCol).setValue(salary);

            logAction("EMPLOYEE_UPDATED", empId, Session.getEffectiveUser().getEmail());

            updateHRDashboard();
            return;
          }

          if (currentStatus !== CONFIG.STATUS.ACTIVE) {

            master.getRange(row, dojCol).setValue(doj);
            master.getRange(row, statusCol).setValue(CONFIG.STATUS.ACTIVE);

            history.appendRow([
              empId, doj, "", CONFIG.STATUS.ACTIVE, "Rejoined", ""
            ]);

            logAction("EMPLOYEE_REJOINED", empId, Session.getEffectiveUser().getEmail());
          }

          break;
        }
      }
    }

    ss.toast("Employee processed", "Success", 3);
    updateHRDashboard();

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);
    throw err;

  } finally {

    lock.releaseLock();

  }

}