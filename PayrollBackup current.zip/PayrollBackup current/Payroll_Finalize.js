// ==============================
// 🔒 FINALIZE PAYROLL (ULTRA SAFE)
// ==============================
function finalizePayroll() {

  try {

    requireAdminAccess();

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getActiveSheet();
    const ui = SpreadsheetApp.getUi();
    const user = Session.getEffectiveUser().getEmail();

    const sheetName = sheet.getName();

    if (!isPayrollSheet(sheetName)) {
      throw new Error("Not a payroll sheet");
    }

    if (sheet.getRange("Z1").getValue() === "FINALIZED") {
      throw new Error("Already finalized");
    }

    // ==============================
    // 🚫 DOUBLE CONFIRM
    // ==============================
    const confirm = ui.alert(
      "FINALIZE PAYROLL",
      "This action is PERMANENT.\n\nProceed?",
      ui.ButtonSet.YES_NO
    );

    if (confirm !== ui.Button.YES) return;

    // ==============================
    // 🛡️ VALIDATION
    // ==============================
    payrollSafetyCheck();

    // ==============================
    // 🚫 BLOCK PENDING
    // ==============================
    const c = CONFIG.COLUMNS;
    const data = sheet.getRange(3,1,sheet.getLastRow()-2,sheet.getLastColumn()).getValues();

    if (data.some(r => r[c.EMP_ID - 1] && r[c.STATUS - 1] === CONFIG.PAYMENT_STATUS.PENDING)) {
      throw new Error("Pending payments exist");
    }

    // ==============================
    // 📦 EXTERNAL BACKUP (SAFE)
    // ==============================
    const backupFile = SpreadsheetApp.create(`Payroll_Backup_${sheetName}_${Date.now()}`);
    const backupSheet = sheet.copyTo(backupFile).setName(sheetName);

    // Remove default sheet
    const defaultSheets = backupFile.getSheets();
    if (defaultSheets.length > 1) {
      backupFile.deleteSheet(defaultSheets[0]);
    }

    // ==============================
    // 🔒 FREEZE VALUES (CRITICAL)
    // ==============================
    const range = sheet.getDataRange();
    range.setValues(range.getValues());

    // ==============================
    // 📦 FULL ARCHIVE
    // ==============================
    archivePayrollToHistoryInternal(sheet);

    // ==============================
    // 🏁 FINAL FLAG + META
    // ==============================
    sheet.getRange("Z1").setValue("FINALIZED");
    sheet.getRange("Z2").setValue("Finalized By: " + user);
    sheet.getRange("Z3").setValue("Finalized At: " + new Date());

    // ==============================
    // 🔒 HARD LOCK
    // ==============================
    sheet.getProtections(SpreadsheetApp.ProtectionType.SHEET)
      .forEach(p => p.remove());

    const protection = sheet.protect().setDescription("FINAL LOCK");

    protection.addEditor(user);
    protection.removeEditors(protection.getEditors());

    if (protection.canDomainEdit()) {
      protection.setDomainEdit(false);
    }

    // ==============================
    // 📜 LOG
    // ==============================
    logAction("PAYROLL_FINALIZED", sheetName, user);

    ui.alert("✅ Payroll finalized & locked permanently.");

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}