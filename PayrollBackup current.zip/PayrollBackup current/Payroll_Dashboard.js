// ==============================
// 📊 PAYROLL DASHBOARD (FINAL)
// ==============================
function generatePayrollDashboard() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const payrollSheet = ss.getActiveSheet();

    const sheetName = payrollSheet.getName();

    // ==============================
    // 🛡️ VALIDATION
    // ==============================
    if (!isPayrollSheet(sheetName)) {
      throw new Error("Not a payroll sheet");
    }

    if (payrollSheet.getRange("Z1").getValue() !== "FINALIZED") {
      throw new Error("Finalize payroll before dashboard");
    }

    const dashboardName = "Payroll_Dashboard";

    let dashboard = ss.getSheetByName(dashboardName);

    if (!dashboard) {
      dashboard = ss.insertSheet(dashboardName);
    }

    // Safe clear
    dashboard.getRange(1,1,50,10).clearContent().clearFormat();

    const lastRow = payrollSheet.getLastRow();
    if (lastRow < 3) throw new Error("No payroll data");

    const totalCols = payrollSheet.getLastColumn();

    const data = payrollSheet
      .getRange(3,1,lastRow-2,totalCols)
      .getValues();

    const c = CONFIG.COLUMNS;

    let totalEmployees = 0;
    let totalGross = 0;
    let totalPF = 0;
    let totalESI = 0;
    let totalNet = 0;
    let totalPaid = 0;
    let totalPending = 0;

    const deptSummary = {};

    // ==============================
    // 📊 PROCESS
    // ==============================
    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];
      if (!empId) return;

      const dept = row[c.DEPARTMENT - 1];

      const gross = Number(row[c.GROSS - 1]) || 0;
      const pf = Number(row[c.PF - 1]) || 0;
      const esi = Number(row[c.ESI - 1]) || 0;
      const net = Number(row[c.NET - 1]) || 0;
      const status = row[c.STATUS - 1];

      if (net <= 0) return;

      totalEmployees++;

      totalGross += gross;
      totalPF += pf;
      totalESI += esi;
      totalNet += net;

      if (status === CONFIG.PAYMENT_STATUS.PAID) totalPaid += net;
      else totalPending += net;

      if (!deptSummary[dept]) {
        deptSummary[dept] = { count: 0, net: 0 };
      }

      deptSummary[dept].count++;
      deptSummary[dept].net += net;

    });

    if (totalEmployees === 0) {
      throw new Error("No valid employee data");
    }

    const avgSalary = Math.round(totalNet / totalEmployees);

    // ==============================
    // 🎯 TITLE
    // ==============================
    dashboard.getRange("A1")
      .setValue("🏥 Town Hospitals Payroll Dashboard")
      .setFontSize(16)
      .setFontWeight("bold");

    // ==============================
    // 📊 KPI BLOCK
    // ==============================
    const kpiData = [
      ["Total Employees", totalEmployees],
      ["Total Gross Salary", totalGross],
      ["Total Net Salary", totalNet],
      ["Total Paid", totalPaid],
      ["Total Pending", totalPending],
      ["Average Salary", avgSalary],
      ["Total PF", totalPF],
      ["Total ESI", totalESI]
    ];

    dashboard.getRange(3,1,kpiData.length,2).setValues(kpiData);

    dashboard.getRange(3,1,kpiData.length,2)
      .setBackground("#f8fbff")
      .setFontWeight("bold");

    // Currency format
    dashboard.getRange(3,2,5,1).setNumberFormat("₹ #,##0");

    // ==============================
    // 🏢 DEPARTMENT TABLE
    // ==============================
    dashboard.getRange(13,1,1,3).setValues([
      ["Department","Employees","Net Salary"]
    ]);

    const deptRows = Object.entries(deptSummary)
      .map(([dept,val]) => [dept, val.count, val.net])
      .sort((a,b) => b[2] - a[2]); // sort by net desc

    if (deptRows.length > 0) {
      dashboard.getRange(14,1,deptRows.length,3).setValues(deptRows);
    }

    dashboard.getRange("A13:C13")
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    dashboard.getRange(14,3,deptRows.length,1)
      .setNumberFormat("₹ #,##0");

    // ==============================
    // 🎨 ALIGNMENT
    // ==============================
    dashboard.getRange(3,1,20,1).setHorizontalAlignment("left");
    dashboard.getRange(3,2,20,1).setHorizontalAlignment("right");

    dashboard.autoResizeColumns(1,5);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYROLL_DASHBOARD_GENERATED",
      sheetName,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("Dashboard generated", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}