// ==============================
// 📊 PAYROLL STATUS SUMMARY (FINAL)
// ==============================
function updatePayrollSummary(sheet) {

  try {

    if (!sheet) return;

    // ==============================
    // 🛡️ VALIDATE PAYROLL SHEET
    // ==============================
    if (!isPayrollSheet(sheet.getName())) return;

    const lastRow = sheet.getLastRow();
    if (lastRow < 3) return;

    const totalCols = sheet.getLastColumn();

    const data = sheet.getRange(3,1,lastRow-2,totalCols).getValues();

    const c = CONFIG.COLUMNS;

    let totalEmployees = 0;
    let totalSalary = 0;

    let paid = 0;
    let hold = 0;
    let pending = 0;

    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];
      const name = row[c.NAME - 1];

      if (!empId || !name) return;

      const netSalary = Number(row[c.NET - 1]) || 0;
      const status = row[c.STATUS - 1];

      totalEmployees++;
      totalSalary += netSalary;

      if (status === CONFIG.PAYMENT_STATUS.PAID) paid++;
      else if (status === CONFIG.PAYMENT_STATUS.HOLD) hold++;
      else pending++;

    });

    if (totalEmployees === 0) return;

    // ==============================
    // 📊 PERCENTAGES
    // ==============================
    const paidPct = Math.round((paid / totalEmployees) * 100);
    const pendingPct = Math.round((pending / totalEmployees) * 100);

    // ==============================
    // 📍 DYNAMIC POSITION
    // ==============================
    const startCol = totalCols + 3;

    sheet.getRange(1,startCol,10,2).clearContent().clearFormat();

    // ==============================
    // 📊 DATA (CLEAN STRUCTURE)
    // ==============================
    const values = [
      ["PAYMENT STATUS", ""],
      ["Employees", totalEmployees],
      ["Total Salary", totalSalary],
      ["Paid", paid],
      ["Hold", hold],
      ["Pending", pending]
    ];

    const range = sheet.getRange(1,startCol,values.length,2);
    range.setValues(values);

    // ==============================
    // 🎨 HEADER STYLE
    // ==============================
    sheet.getRange(1,startCol,1,2)
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    // ==============================
    // 🎨 BODY STYLE
    // ==============================
    sheet.getRange(2,startCol,values.length-1,2)
      .setBackground("#f8fbff");

    // Alignment
    sheet.getRange(2,startCol,values.length-1,1)
      .setHorizontalAlignment("left");

    sheet.getRange(2,startCol,values.length-1,2)
      .setHorizontalAlignment("right");

    // Currency format
    sheet.getRange(3,startCol+1)
      .setNumberFormat("₹ #,##0");

    // ==============================
    // 📊 PERCENTAGE DISPLAY (SIDE)
    // ==============================
    sheet.getRange(7,startCol,2,2).setValues([
      ["Paid %", paidPct + "%"],
      ["Pending %", pendingPct + "%"]
    ]);

    // ==============================
    // 🎯 CONDITIONAL COLORS
    // ==============================
    if (paidPct === 100) {
      sheet.getRange(4,startCol,1,2)
        .setBackground(CONFIG.COLORS.PAID);
    }

    if (pending > 0) {
      sheet.getRange(6,startCol,1,2)
        .setBackground(CONFIG.COLORS.HOLD);
    }

    range.setBorder(true,true,true,true,false,false);

  } catch (err) {

    Logger.log("Payroll Summary Error: " + err.message);

  }

}