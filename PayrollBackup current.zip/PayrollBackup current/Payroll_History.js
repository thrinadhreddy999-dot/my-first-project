function archivePayrollToHistory() {

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const payrollSheet = ss.getActiveSheet();
  const historySheet = ss.getSheetByName(CONFIG.SHEETS.PAYROLL_HISTORY);

  if (!historySheet) {
    throw new Error("PAYROLL_HISTORY sheet not found.");
  }

  const sheetName = payrollSheet.getName();

  // ==============================
  // VALIDATE PAYROLL SHEET
  // ==============================
  if (!isPayrollSheet(sheetName)) {
    throw new Error("This is not a payroll sheet.");
  }

  const lastRow = payrollSheet.getLastRow();
  if (lastRow < 3) return;

  const data = payrollSheet.getRange(3,1,lastRow-2,20).getValues();
  const c = CONFIG.COLUMNS;

  try {

    // ==============================
    // PREVENT DUPLICATE ARCHIVE
    // ==============================
    const historyLastRow = historySheet.getLastRow();

    if (historyLastRow > 1) {

      const existingMonths = historySheet
        .getRange(2,1,historyLastRow-1,1)
        .getValues()
        .flat();

      if (existingMonths.includes(sheetName)) {
        throw new Error("This payroll is already archived.");
      }

    }

    // ==============================
    // BUILD DATA
    // ==============================
    const archiveData = [];

    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];

      if (!empId) return;

      const net = Number(row[c.NET - 1]) || 0;
      if (net === 0) return;

      archiveData.push([
        sheetName,
        row[c.EMP_ID - 1],
        row[c.NAME - 1],
        row[c.DEPARTMENT - 1],
        row[c.MONTHLY_SALARY - 1],
        row[c.GROSS - 1],
        row[c.PF - 1],
        row[c.ESI - 1],
        row[c.PT - 1],
        row[c.TOTAL_DEDUCTION - 1],
        row[c.NET - 1]
      ]);

    });

    // ==============================
    // WRITE DATA
    // ==============================
    if (archiveData.length > 0) {

      historySheet.getRange(
        historySheet.getLastRow() + 1,
        1,
        archiveData.length,
        archiveData[0].length
      ).setValues(archiveData);

    }

  } catch (err) {

    throw new Error("Archive Error:\n" + err.message);

  }

}