// ==============================
// 🎛️ ENTERPRISE MENU SYSTEM (FINAL)
// ==============================

function onOpen() {

  const ui = SpreadsheetApp.getUi();
  const admin = isAdmin();

  const menu = ui.createMenu("🏥 Town Payroll");

  // ==============================
  // 👨‍⚕️ EMPLOYEE SYSTEM
  // ==============================
  menu.addSubMenu(
    ui.createMenu("👨‍⚕️ Employee System")
      .addItem("➕ Add / Rejoin Employee", "safe_openEmployeeForm")
      .addItem("🚪 Exit Employee", "safe_openExitPrompt")
      .addSeparator()
      .addItem("📜 Employment History", "safe_openEmploymentHistory")
  );

  // ==============================
  // ⚡ QUICK ACTIONS
  // ==============================
  menu.addSubMenu(
    ui.createMenu("⚡ Quick Actions")
      .addItem("🧮 Calculate Payroll", "safe_calculatePayroll")
      .addItem("📊 Refresh Dashboard", "safe_updatePaymentDashboard")
  );

  // ==============================
  // 📄 PAYROLL
  // ==============================
  menu.addSubMenu(
    ui.createMenu("📄 Payroll Processing")
      .addItem("🆕 Generate Payroll", "safe_createPayroll")
      .addItem("📊 Update Summary", "safe_updatePayrollSummary")
  );

  // ==============================
  // 💰 PAYMENTS
  // ==============================
  menu.addSubMenu(
    ui.createMenu("💰 Payments")
      .addItem("🏦 Bank Transfer Sheet", "safe_generateBankTransfer")
      .addItem("✅ Mark as Paid", "safe_markPaid")
      .addItem("⏸ Mark as Hold", "safe_markHold")
  );

  // ==============================
  // 📊 ANALYTICS
  // ==============================
  menu.addSubMenu(
    ui.createMenu("📊 Analytics")
      .addItem("📈 Payroll Dashboard", "safe_payrollDashboard")
      .addItem("🏢 Department Analytics", "safe_departmentAnalytics")
      .addItem("📅 Yearly Analytics", "safe_yearlyAnalytics")
      .addItem("📑 PF & ESI Report", "safe_pfEsiReport")
  );

  // ==============================
  // 📄 PAYSLIPS
  // ==============================
  menu.addSubMenu(
    ui.createMenu("📄 Payslips")
      .addItem("🧾 Generate Payslips", "safe_generatePayslips")
      .addItem("📧 Send Payslips", "safe_sendPayslips")
  );

  // ==============================
  // 👥 HR CONTROL
  // ==============================
  menu.addSubMenu(
    ui.createMenu("👥 HR Control")
      .addItem("📢 HR Alerts", "safe_hrAlerts")
      .addItem("📊 PF/ESI Tracker", "safe_pfEsiTracker")
      .addItem("🗂 Archive Payroll", "safe_archivePayroll")
  );

  // ==============================
  // 🔒 ADMIN
  // ==============================
  if (admin) {

    menu.addSubMenu(
      ui.createMenu("🔒 Admin")
        .addItem("✅ Finalize Payroll", "safe_finalizePayroll")
        .addItem("♻️ Undo Finalize", "safe_undoFinalize")
        .addSeparator()
        .addItem("🔒 Lock Sheet", "safe_lockSheet")
        .addItem("🔓 Unlock Sheet", "safe_unlockSheet")
    );

  }

  // ==============================
  // ⚙ SYSTEM
  // ==============================
  menu.addSubMenu(
    ui.createMenu("⚙ System")
      .addItem("💾 Backup", "safe_backupSystem")
      .addItem("🎨 Format Sheets", "safe_formatSheets")
  );

  menu.addToUi();
}


// ==============================
// 🛡️ SAFE EXECUTION WRAPPER
// ==============================
function safeExecute(fnName) {

  try {

    if (typeof this[fnName] !== "function") {
      throw new Error("Function not implemented: " + fnName);
    }

    this[fnName]();

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}


// ==============================
// 🔗 SAFE WRAPPERS
// ==============================
function safe_calculatePayroll() { safeExecute("calculatePayroll"); }
function safe_createPayroll() { safeExecute("createNextMonthPayroll"); }
function safe_updatePayrollSummary() { safeExecute("updatePayrollSummaryManual"); }
function safe_generateBankTransfer() { safeExecute("generateBankTransferSheet"); }
function safe_markPaid() { safeExecute("markSelectedAsPaid"); }
function safe_markHold() { safeExecute("markSelectedAsHold"); }
function safe_payrollDashboard() { safeExecute("generatePayrollDashboard"); }
function safe_departmentAnalytics() { safeExecute("generateDepartmentAnalytics"); }
function safe_yearlyAnalytics() { safeExecute("generateYearlyPayrollAnalytics"); }
function safe_pfEsiReport() { safeExecute("generatePFESIReport"); }
function safe_generatePayslips() { safeExecute("generatePayslips"); }
function safe_sendPayslips() { safeExecute("sendPayslipsEmail"); }
function safe_hrAlerts() { safeExecute("generateHRAlerts"); }
function safe_pfEsiTracker() { safeExecute("updatePFESITracker"); }
function safe_archivePayroll() { safeExecute("archivePayrollToHistory"); }
function safe_finalizePayroll() { safeExecute("finalizePayroll"); }
function safe_undoFinalize() { safeExecute("undoFinalizePayroll"); }
function safe_lockSheet() { safeExecute("lockPayrollSheet"); }
function safe_unlockSheet() { safeExecute("unlockPayrollSheet"); }
function safe_backupSystem() { safeExecute("backupPayrollSystem"); }
function safe_formatSheets() { safeExecute("formatAllSheetsLayout"); }
function safe_updatePaymentDashboard() { safeExecute("updatePaymentDashboard"); }
function safe_openEmployeeForm() { safeExecute("openEmployeeForm"); }
function safe_openExitPrompt() { safeExecute("openExitPrompt"); }
function safe_openEmploymentHistory() { safeExecute("openEmploymentHistory"); }


// ==============================
// 📊 MANUAL SUMMARY
// ==============================
function updatePayrollSummaryManual() {

  const sheet = SpreadsheetApp.getActiveSheet();

  if (!isPayrollSheet(sheet.getName())) {
    SpreadsheetApp.getUi().alert("Not a payroll sheet.");
    return;
  }

  updatePayrollSummary(sheet);

  SpreadsheetApp.getActiveSpreadsheet()
    .toast("Summary Updated", "Success", 2);
}