// ==============================
// 🔍 GET FULL EMPLOYEE PROFILE
// ==============================
function getEmployeeFullProfile(empId) {

  if (!empId) return null;

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
  const details = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

  const masterData = master.getDataRange().getValues();
  const detailsData = details.getDataRange().getValues();

  let profile = null;

  // ==============================
  // MASTER DATA
  // ==============================
  for (let i = 1; i < masterData.length; i++) {

    if (masterData[i][0] === empId) {

      profile = {
        empId: empId,
        first: masterData[i][1],
        last: masterData[i][2],
        department: masterData[i][3],
        designation: masterData[i][4],
        salary: masterData[i][6],
        doj: masterData[i][8],
        status: masterData[i][10]
      };

      break;
    }
  }

  if (!profile) return null;

  // ==============================
  // DETAILS DATA
  // ==============================
  const mobileCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.MOBILE);
  const empIdCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.EMP_ID);

  for (let i = 1; i < detailsData.length; i++) {

    if (detailsData[i][empIdCol - 1] === empId) {

      profile.mobile = detailsData[i][mobileCol - 1];
      break;
    }
  }

  return profile;
}

// ==============================
// 👤 OPEN PROFILE SCREEN
// ==============================
function openEmployeeProfile() {

  try {

    requireAdminAccess();

    const html = HtmlService
      .createHtmlOutputFromFile("EmployeeProfile")
      .setWidth(600)
      .setHeight(650);

    SpreadsheetApp.getUi()
      .showModalDialog(html, "👤 Employee Profile");

  } catch (err) {

    SpreadsheetApp.getUi().alert(err.message);

  }

}