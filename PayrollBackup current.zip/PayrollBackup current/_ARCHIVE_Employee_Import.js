// ==============================
// ⚠️ ARCHIVED MODULE - SAFE VERSION
// ==============================
function importEmployeesFromPetPooja() {
  throw new Error("❌ This module is archived. Do not use directly.");
}


// ==============================
// 🧠 FUTURE BULK IMPORT ENGINE (ELITE SAFE)
// ==============================
function safeBulkEmployeeImport(dataRows) {

  try {

    if (!Array.isArray(dataRows) || dataRows.length === 0) {
      throw new Error("No data provided for import");
    }

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const details = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

    if (!master || !details) {
      throw new Error("Required sheets missing");
    }

    // ==============================
    // 📌 COLUMN INDEXES
    // ==============================
    const mobileCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.MOBILE);
    const empIdCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.EMP_ID);

    // ==============================
    // 📊 EXISTING MOBILE MAP
    // ==============================
    const existingData = details.getDataRange().getValues();
    const existingMobiles = new Set();

    for (let i = 1; i < existingData.length; i++) {
      const m = String(existingData[i][mobileCol - 1]).replace(/\s+/g,"").trim();
      if (m) existingMobiles.add(m);
    }

    // ==============================
    // 🆔 PRE-GENERATE IDS (SAFE)
    // ==============================
    const newCount = dataRows.length;
    let baseId = generateEmployeeId();
    let baseNum = parseInt(baseId.replace("TH-EMP-", "")) || 1;

    const generateNextId = () => {
      baseNum++;
      return "TH-EMP-" + String(baseNum).padStart(3, "0");
    };

    const masterRows = [];
    const detailsRows = [];

    let success = 0;
    let skipped = 0;

    // ==============================
    // 🔄 PROCESS DATA
    // ==============================
    dataRows.forEach(row => {

      try {

        const mobile = String(row.mobile || "").replace(/\s+/g,"").trim();
        const first = String(row.first || "").trim();
        const dept = String(row.department || "").trim();
        const salary = Number(row.salary) || 0;

        // ==============================
        // 🛑 VALIDATION
        // ==============================
        if (!mobile || !first || !dept || salary <= 0) {
          skipped++;
          return;
        }

        if (existingMobiles.has(mobile)) {
          skipped++;
          return;
        }

        // ==============================
        // 📅 DATE VALIDATION
        // ==============================
        let doj = "";

        if (row.doj) {
          const d = new Date(row.doj);
          if (!isNaN(d)) {
            doj = d;
          }
        }

        // ==============================
        // 🆔 SAFE ID
        // ==============================
        const empId = generateNextId();

        // ==============================
        // 🧾 MASTER ROW
        // ==============================
        masterRows.push([
          empId,
          row.first || "",
          row.last || "",
          row.department || "",
          row.designation || "",
          CONFIG.DEFAULTS.EMPLOYMENT_TYPE,
          salary,
          CONFIG.DEFAULTS.SALARY_TYPE,
          doj,
          "",
          CONFIG.STATUS.ACTIVE,
          "", "", "", "", "", "", ""
        ]);

        // ==============================
        // 📋 DETAILS ROW
        // ==============================
        const newDetails = new Array(details.getLastColumn()).fill("");
        newDetails[empIdCol - 1] = empId;
        newDetails[mobileCol - 1] = mobile;

        detailsRows.push(newDetails);

        existingMobiles.add(mobile);
        success++;

      } catch (innerErr) {
        skipped++;
      }

    });

    // ==============================
    // 💾 WRITE DATA (BATCH)
    // ==============================
    if (masterRows.length) {
      master.getRange(master.getLastRow()+1,1,masterRows.length,masterRows[0].length)
        .setValues(masterRows);
    }

    if (detailsRows.length) {
      details.getRange(details.getLastRow()+1,1,detailsRows.length,detailsRows[0].length)
        .setValues(detailsRows);
    }

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "Bulk Employee Import",
      `Success: ${success}, Skipped: ${skipped}`,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast(`Import Complete: ${success} added, ${skipped} skipped`, "Import Summary", 5);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ Import failed: " + err.message);

  }

}