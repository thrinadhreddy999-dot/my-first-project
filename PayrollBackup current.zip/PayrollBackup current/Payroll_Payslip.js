// ==============================
// 🧾 PAYSLIP GENERATOR (FINAL SAFE)
// ==============================
function generatePayslips() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const payrollSheet = ss.getActiveSheet();

    // ==============================
    // 🔒 FINALIZATION CHECK
    // ==============================
    if (payrollSheet.getRange("Z1").getValue() !== "FINALIZED") {
      throw new Error("Payroll not finalized");
    }

    const month = payrollSheet.getName();

    const parentFolderName = "Town_Payroll_Payslips";

    const parentFolders = DriveApp.getFoldersByName(parentFolderName);
    const parentFolder = parentFolders.hasNext()
      ? parentFolders.next()
      : DriveApp.createFolder(parentFolderName);

    // 📁 Month folder
    const monthFolderName = month.replace(" ", "_");
    const subFolders = parentFolder.getFoldersByName(monthFolderName);
    const folder = subFolders.hasNext()
      ? subFolders.next()
      : parentFolder.createFolder(monthFolderName);

    const lastRow = payrollSheet.getLastRow();
    if (lastRow < 3) return;

    const data = payrollSheet.getRange(3,1,lastRow-2,20).getValues();
    const c = CONFIG.COLUMNS;

    const formatCurrency = val =>
      "₹ " + (Number(val || 0)).toLocaleString("en-IN");

    let generated = 0;
    let skipped = 0;

    data.forEach(row => {

      try {

        const empId = row[c.EMP_ID - 1];
        if (!empId) return;

        const name = row[c.NAME - 1];
        const dept = row[c.DEPARTMENT - 1];
        const net = row[c.NET - 1];

        if (!name || !dept || !net) {
          skipped++;
          return;
        }

        const salary = row[c.MONTHLY_SALARY - 1];
        const gross = row[c.GROSS - 1];
        const pf = row[c.PF - 1];
        const esi = row[c.ESI - 1];
        const pt = row[c.PT - 1];

        // ==============================
        // SAFE FILE DELETE (EXACT)
        // ==============================
        const files = folder.getFilesByName(`Payslip_${month}_${empId}.pdf`);
        while (files.hasNext()) {
          files.next().setTrashed(true);
        }

        // ==============================
        // HTML DESIGN (PRO)
        // ==============================
        const html = `
        <div style="font-family: Arial; padding:25px;">

          <h2 style="text-align:center;">
            TOWN HOSPITALS
          </h2>

          <p style="text-align:center;">
            Salary Slip - ${month}
          </p>

          <hr>

          <table width="100%">
            <tr>
              <td><b>ID:</b> ${empId}</td>
              <td><b>Dept:</b> ${dept}</td>
            </tr>
            <tr>
              <td><b>Name:</b> ${name}</td>
              <td><b>Month:</b> ${month}</td>
            </tr>
          </table>

          <br>

          <table border="1" width="100%" style="border-collapse:collapse;">
            <tr>
              <th>Earnings</th><th>Amount</th>
            </tr>
            <tr>
              <td>Monthly Salary</td>
              <td align="right">${formatCurrency(salary)}</td>
            </tr>
            <tr>
              <td><b>Gross</b></td>
              <td align="right"><b>${formatCurrency(gross)}</b></td>
            </tr>
          </table>

          <br>

          <table border="1" width="100%" style="border-collapse:collapse;">
            <tr>
              <th>Deductions</th><th>Amount</th>
            </tr>
            <tr><td>PF</td><td align="right">${formatCurrency(pf)}</td></tr>
            <tr><td>ESI</td><td align="right">${formatCurrency(esi)}</td></tr>
            <tr><td>PT</td><td align="right">${formatCurrency(pt)}</td></tr>
          </table>

          <br>

          <h3 style="text-align:right;">
            Net: ${formatCurrency(net)}
          </h3>

          <p style="text-align:right; font-size:12px;">
            Authorized Signatory
          </p>

        </div>
        `;

        const blob = Utilities.newBlob(html, "text/html")
          .getAs("application/pdf")
          .setName(`Payslip_${month}_${empId}.pdf`);

        folder.createFile(blob);

        generated++;

      } catch (innerErr) {
        skipped++;
      }

    });

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYSLIPS_GENERATED",
      `Generated: ${generated}, Skipped: ${skipped}`,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet().toast(
      `Payslips: ${generated} generated`,
      "Success",
      4
    );

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}