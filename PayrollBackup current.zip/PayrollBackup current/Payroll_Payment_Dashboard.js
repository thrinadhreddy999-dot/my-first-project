// ==============================
// 📊 PAYMENT DASHBOARD ENGINE (FINAL)
// ==============================
function updatePaymentDashboard() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getActiveSheet();

    const dashboard = ss.getSheetByName(CONFIG.SHEETS.PAYMENT_DASHBOARD);

    if (!dashboard) return;

    const sheetName = sheet.getName();

    // ==============================
    // 🛡️ ONLY PAYROLL SHEETS
    // ==============================
    if (!isPayrollSheet(sheetName)) return;

    const lastRow = sheet.getLastRow();
    if (lastRow < 3) return;

    const totalCols = sheet.getLastColumn();
    const data = sheet.getRange(3,1,lastRow-2,totalCols).getValues();

    const c = CONFIG.COLUMNS;

    let totalEmployees = 0;
    let paidEmployees = 0;
    let pendingEmployees = 0;
    let holdEmployees = 0;

    let totalSalary = 0;
    let paidSalary = 0;

    // ==============================
    // 📊 CALCULATION
    // ==============================
    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];
      if (!empId) return;

      const netSalary = Number(row[c.NET - 1]) || 0;
      const status = row[c.STATUS - 1];

      totalEmployees++;
      totalSalary += netSalary;

      if (status === CONFIG.PAYMENT_STATUS.PAID) {
        paidEmployees++;
        paidSalary += netSalary;
      }
      else if (status === CONFIG.PAYMENT_STATUS.PENDING) {
        pendingEmployees++;
      }
      else if (status === CONFIG.PAYMENT_STATUS.HOLD) {
        holdEmployees++;
      }

    });

    if (totalEmployees === 0) return;

    const remainingSalary = totalSalary - paidSalary;

    const paidPct = Math.round((paidEmployees / totalEmployees) * 100);
    const pendingPct = Math.round((pendingEmployees / totalEmployees) * 100);

    // ==============================
    // 🧹 CLEAR (DYNAMIC SAFE)
    // ==============================
    const maxCols = 6;
    dashboard.getRange(1,1,20,maxCols).clearContent().clearFormat();

    // ==============================
    // 📊 HEADER
    // ==============================
    dashboard.getRange(1,1)
      .setValue("PAYMENT DASHBOARD");

    dashboard.getRange(1,1,1,4)
      .merge()
      .setFontSize(14)
      .setFontWeight("bold")
      .setHorizontalAlignment("center")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT);

    dashboard.getRange(2,1).setValue("Payroll Month:");
    dashboard.getRange(2,2).setValue(sheetName);

    // ==============================
    // 📊 EMPLOYEE STATS
    // ==============================
    const empData = [
      ["Employees", totalEmployees],
      ["Paid", paidEmployees],
      ["Pending", pendingEmployees],
      ["Hold", holdEmployees]
    ];

    dashboard.getRange(4,1,empData.length,2).setValues(empData);

    // ==============================
    // 💰 SALARY STATS
    // ==============================
    const salaryData = [
      ["Total Salary", totalSalary],
      ["Paid Salary", paidSalary],
      ["Remaining", remainingSalary]
    ];

    dashboard.getRange(4,3,salaryData.length,2).setValues(salaryData);

    // ==============================
    // 📊 PERCENTAGE BLOCK
    // ==============================
    dashboard.getRange(8,1,2,2).setValues([
      ["Paid %", paidPct + "%"],
      ["Pending %", pendingPct + "%"]
    ]);

    // ==============================
    // 🎨 STYLING
    // ==============================
    dashboard.getRange(4,1,4,4)
      .setBackground("#f8fbff")
      .setBorder(true,true,true,true,false,false);

    // Alignment
    dashboard.getRange(4,1,6,1).setHorizontalAlignment("left");
    dashboard.getRange(4,2,6,1).setHorizontalAlignment("right");
    dashboard.getRange(4,3,6,1).setHorizontalAlignment("left");
    dashboard.getRange(4,4,6,1).setHorizontalAlignment("right");

    // Currency format
    dashboard.getRange(4,4,3,1).setNumberFormat("₹ #,##0");

    // ==============================
    // 🎯 ALERT COLORS
    // ==============================
    if (pendingEmployees > 0) {
      dashboard.getRange(6,1,1,2)
        .setBackground(CONFIG.COLORS.HOLD);
    }

    if (paidPct === 100) {
      dashboard.getRange(5,1,1,2)
        .setBackground(CONFIG.COLORS.PAID);
    }

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYMENT_DASHBOARD_UPDATED",
      sheetName,
      Session.getEffectiveUser().getEmail()
    );

  } catch (err) {

    Logger.log("Dashboard Error: " + err.message);

  }

}