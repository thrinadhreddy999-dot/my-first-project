// ==============================
// 🔒 LOCK PAYROLL (CONTROLLED)
// ==============================
function lockPayrollSheet() {

  try {

    requireAdminAccess();

    const sheet = SpreadsheetApp.getActiveSheet();
    const name = sheet.getName();

    if (!isPayrollSheet(name)) {
      throw new Error("Not a payroll sheet");
    }

    if (sheet.getRange("Z1").getValue() === "FINALIZED") {
      throw new Error("Already finalized. Cannot apply soft lock.");
    }

    protectPayrollSheet(sheet);

    logAction("PAYROLL_LOCKED", name, Session.getEffectiveUser().getEmail());

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("Payroll locked (controlled editing)", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}


// ==============================
// 🔓 UNLOCK PAYROLL (SAFE)
// ==============================
function unlockPayrollSheet() {

  try {

    requireAdminAccess();

    const sheet = SpreadsheetApp.getActiveSheet();
    const name = sheet.getName();

    if (!isPayrollSheet(name)) {
      throw new Error("Not a payroll sheet");
    }

    // 🚨 BLOCK FINALIZED UNLOCK
    if (sheet.getRange("Z1").getValue() === "FINALIZED") {
      throw new Error("Finalized payroll cannot be unlocked");
    }

    sheet.getProtections(SpreadsheetApp.ProtectionType.SHEET)
      .forEach(p => p.remove());

    logAction("PAYROLL_UNLOCKED", name, Session.getEffectiveUser().getEmail());

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("Payroll unlocked", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}