function formatAllSheetsLayout() {

  const lock = LockService.getScriptLock();

  try {

    lock.waitLock(10000);

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const user = Session.getEffectiveUser().getEmail();

    const admins = CONFIG.ADMINS || [];
    if (!admins.includes(user)) {
      throw new Error("Unauthorized formatting access");
    }

    if (!CONFIG || !CONFIG.COLORS) {
      throw new Error("CONFIG missing");
    }

    const sheets = ss.getSheets();

    sheets.forEach(sheet => {

      try {

        const name = sheet.getName();

        if (
          name === CONFIG.SHEETS.SYSTEM_LOG ||
          name === CONFIG.SHEETS.IMPORT
        ) return;

        const lastRow = sheet.getLastRow();
        const lastCol = sheet.getLastColumn();

        if (lastCol === 0) return;

        const isPayroll = isPayrollSheet(name);
        const headerRow = isPayroll ? 2 : 1;

        const headerRange = sheet.getRange(headerRow, 1, 1, lastCol);

        // ==============================
        // HEADER STYLE
        // ==============================
        headerRange
          .setFontWeight("bold")
          .setFontSize(11)
          .setHorizontalAlignment("center")
          .setVerticalAlignment("middle")
          .setBackground(CONFIG.COLORS.HEADER_BG)
          .setFontColor(CONFIG.COLORS.HEADER_TEXT);

        sheet.setFrozenRows(headerRow);

        if (lastRow > headerRow) {

          const rowCount = lastRow - headerRow;

          const dataRange = sheet.getRange(headerRow + 1, 1, rowCount, lastCol);

          // ==============================
          // BATCH ALT COLORS (FAST)
          // ==============================
          const bg = [];

          for (let i = 0; i < rowCount; i++) {
            const color = i % 2 === 0 ? "#ffffff" : "#f8fbff";
            bg.push(new Array(lastCol).fill(color));
          }

          dataRange.setBackgrounds(bg);

          dataRange.setVerticalAlignment("middle")
            .setFontSize(10);

          // OPTIONAL RESIZE
          if (lastCol < 20) {
            sheet.autoResizeColumns(1, lastCol);
          }
        }

        // ==============================
        // PAYROLL NUMBER FORMAT
        // ==============================
        if (isPayroll) {

          const c = CONFIG.COLUMNS;

          [
            c.MONTHLY_SALARY,
            c.GROSS,
            c.TOTAL_DEDUCTION,
            c.NET
          ].forEach(col => {

            if (col && col <= lastCol) {
              sheet.getRange(headerRow + 1, col, lastRow - headerRow)
                .setNumberFormat("₹ #,##0");
            }

          });
        }

      } catch (err) {
        Logger.log(`Format skip: ${sheet.getName()} → ${err.message}`);
      }

    });

  } catch (err) {

    Logger.log("Format Engine Error: " + err.message);
    throw err;

  } finally {

    lock.releaseLock();

  }

}