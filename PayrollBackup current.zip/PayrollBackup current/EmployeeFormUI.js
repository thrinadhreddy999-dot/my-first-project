// ==============================
// 🧑‍💼 OPEN EMPLOYEE FORM (SMART UI)
// ==============================
function openEmployeeForm() {

  try {

    const user = Session.getEffectiveUser().getEmail();
    const admins = CONFIG.ADMINS || [];

    // ==============================
    // 🔒 ACCESS CONTROL (OPTIONAL)
    // ==============================
    if (admins.length && !admins.includes(user)) {
      SpreadsheetApp.getUi().alert("You are not authorized to access this form.");
      return;
    }

    // ==============================
    // 🎯 LOAD HTML
    // ==============================
    const html = HtmlService
      .createHtmlOutputFromFile('employeeForm')
      .setWidth(520)
      .setHeight(700);

    // ==============================
    // 🚀 SHOW MODAL
    // ==============================
    SpreadsheetApp.getUi()
      .showModalDialog(html, "👨‍⚕️ Employee Management");

  } catch (err) {

    SpreadsheetApp.getUi().alert("Error opening form:\n" + err.message);

  }

}