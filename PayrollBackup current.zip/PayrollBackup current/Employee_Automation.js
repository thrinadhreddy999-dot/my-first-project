// ==============================
// 🤖 EMPLOYEE AUTOMATION ENGINE (ELITE FINAL)
// ==============================
function employeeAutomation(e) {

  const lock = LockService.getScriptLock();

  try {

    if (!e || !e.range) return;

    const sheet = e.source.getActiveSheet();
    const sheetName = sheet.getName();
    const row = e.range.getRow();
    const col = e.range.getColumn();

    // ==============================
    // 🔒 BASIC GUARDS
    // ==============================
    if (row < 2) return;
    if (sheetName !== CONFIG.SHEETS.EMPLOYEE_MASTER) return;

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const detailsSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

    if (!detailsSheet) {
      throw new Error("EMPLOYEE_DETAILS sheet not found");
    }

    // ==============================
    // 🔒 LOCK (CRITICAL)
    // ==============================
    lock.waitLock(3000);

    // ==============================
    // 📌 COLUMN CACHE
    // ==============================
    const cols = {
      empId: getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.EMP_ID),
      first: getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.FIRST_NAME),
      last: getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.LAST_NAME),
      doj: getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.DOJ),
      probation: getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.PROBATION)
    };

    const dCols = {
      empId: getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.EMP_ID),
      name: getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.NAME)
    };

    // ==============================
    // 🎯 TRIGGER CONTROL
    // ==============================
    if (![cols.first, cols.last, cols.doj].includes(col)) return;

    // ==============================
    // 📊 ROW DATA (SINGLE READ)
    // ==============================
    const rowData = sheet.getRange(row, 1, 1, sheet.getLastColumn()).getValues()[0];

    let empId = String(rowData[cols.empId - 1] || "").trim();
    const first = String(rowData[cols.first - 1] || "").trim();
    const last = String(rowData[cols.last - 1] || "").trim();
    const doj = rowData[cols.doj - 1];

    // ==============================
    // 🆔 AUTO ID GENERATION
    // ==============================
    if (!empId && first) {

      empId = generateEmployeeId();
      sheet.getRange(row, cols.empId).setValue(empId);
    }

    if (!empId || !first) return;

    // ==============================
    // 🧾 CLEAN DISPLAY NAME
    // ==============================
    const displayName = [first, last].filter(Boolean).join(" ").toUpperCase();

    // ==============================
    // 🔍 FIND IN DETAILS
    // ==============================
    const lastRow = detailsSheet.getLastRow();

    let foundRow = -1;

    if (lastRow >= 2) {

      const idRange = detailsSheet
        .getRange(2, dCols.empId, lastRow - 1, 1)
        .getValues();

      for (let i = 0; i < idRange.length; i++) {

        if (String(idRange[i][0]).trim() === empId) {
          foundRow = i + 2;
          break;
        }
      }
    }

    // ==============================
    // ➕ CREATE ENTRY (SAFE WRITE)
    // ==============================
    if (foundRow === -1) {

      const newRow = new Array(detailsSheet.getLastColumn()).fill("");

      newRow[dCols.empId - 1] = empId;
      newRow[dCols.name - 1] = displayName;

      const nextRow = detailsSheet.getLastRow() + 1;
      detailsSheet.getRange(nextRow, 1, 1, newRow.length).setValues([newRow]);
    }

    // ==============================
    // 🔄 UPDATE NAME
    // ==============================
    else {

      const currentName = detailsSheet.getRange(foundRow, dCols.name).getValue();

      if (currentName !== displayName) {
        detailsSheet.getRange(foundRow, dCols.name).setValue(displayName);
      }
    }

    // ==============================
    // ⏳ AUTO PROBATION
    // ==============================
    if (doj) {

      const probationValue = rowData[cols.probation - 1];

      const parsedDate = new Date(doj);

      if (!probationValue && !isNaN(parsedDate)) {

        parsedDate.setMonth(parsedDate.getMonth() + 3);
        sheet.getRange(row, cols.probation).setValue(parsedDate);
      }
    }

  } catch (err) {

    Logger.log("Employee Automation Error: " + err.message);

  } finally {

    lock.releaseLock(); // 🔓 ALWAYS RELEASE
  }

}