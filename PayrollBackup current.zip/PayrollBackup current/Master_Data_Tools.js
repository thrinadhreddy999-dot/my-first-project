// ==============================
// 🏥 EMPLOYEE ENGINE (FINAL SAFE)
// ==============================
function processEmployeeForm(data) {

  try {

    if (!data) throw new Error("No data received");

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const details = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);
    const history = ss.getSheetByName("EMPLOYMENT_HISTORY");

    if (!master || !details) {
      throw new Error("Required sheets missing");
    }

    // ==============================
    // 🧹 CLEAN INPUT
    // ==============================
    const mobile = String(data.mobile || "").replace(/\s+/g,"").trim();
    const first = String(data.first || "").trim();
    const last = String(data.last || "").trim();
    const dept = String(data.department || "").trim();
    const designation = String(data.designation || "").trim();
    const salary = Number(data.salary) || 0;

    if (!mobile || !first || !dept || !designation || salary <= 0) {
      throw new Error("Invalid input data");
    }

    let doj = "";
    if (data.doj) {
      const d = new Date(data.doj);
      if (!isNaN(d)) doj = d;
    }

    // ==============================
    // 🔍 DETAILS LOOKUP
    // ==============================
    const lastRow = details.getLastRow();

    const mobileCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.MOBILE);
    const empIdCol = getColumnIndex(details, CONFIG.DETAILS_COLUMNS.EMP_ID);

    const detailsData = lastRow > 1
      ? details.getRange(2,1,lastRow-1,details.getLastColumn()).getValues()
      : [];

    let empId = "";

    for (let i=0;i<detailsData.length;i++){
      const m = String(detailsData[i][mobileCol-1]).replace(/\s+/g,"").trim();
      if (m === mobile){
        empId = detailsData[i][empIdCol-1];
        break;
      }
    }

    // ==============================
    // 🆕 NEW EMPLOYEE
    // ==============================
    if (!empId) {

      empId = generateEmployeeId();

      master.appendRow([
        empId, first, last, dept, designation,
        CONFIG.DEFAULTS.EMPLOYMENT_TYPE,
        salary,
        CONFIG.DEFAULTS.SALARY_TYPE,
        doj,
        "",
        CONFIG.STATUS.ACTIVE,
        "", "", "", ""
      ]);

      const newRow = new Array(details.getLastColumn()).fill("");
      newRow[empIdCol - 1] = empId;
      newRow[mobileCol - 1] = mobile;

      details.appendRow(newRow);

      if (history) {
        history.appendRow([empId, doj, "", CONFIG.STATUS.ACTIVE, "New Joining", ""]);
      }

      logAction("EMPLOYEE_CREATED", empId, Session.getEffectiveUser().getEmail());
    }

    // ==============================
    // 🔁 REJOIN
    // ==============================
    else {

      const masterData = master.getDataRange().getValues();

      for (let i=1;i<masterData.length;i++){

        if (masterData[i][0] === empId){

          const statusCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.STATUS);
          const dojCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.DOJ);

          const currentStatus = master.getRange(i+1,statusCol).getValue();

          if (![CONFIG.STATUS.ACTIVE, CONFIG.STATUS.PROBATION].includes(currentStatus)) {

            master.getRange(i+1,dojCol).setValue(doj);
            master.getRange(i+1,statusCol).setValue(CONFIG.STATUS.ACTIVE);

            if (history) {
              history.appendRow([empId, doj, "", CONFIG.STATUS.ACTIVE, "Rejoined", ""]);
            }

            logAction("EMPLOYEE_REJOINED", empId, Session.getEffectiveUser().getEmail());
          }

          break;
        }
      }
    }

    ss.toast("Employee processed", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);
    throw err;

  }
}