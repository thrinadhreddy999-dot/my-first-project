// ==============================
// 🚪 OPEN EXIT FORM (ADMIN ONLY)
// ==============================
function openExitForm() {

  try {

    // ==============================
    // 🔒 ADMIN CHECK
    // ==============================
    requireAdminAccess();

    // ==============================
    // 🎯 LOAD HTML
    // ==============================
    const html = HtmlService
      .createHtmlOutputFromFile("EmployeeExitForm")
      .setWidth(450)
      .setHeight(500);

    // ==============================
    // 🚀 SHOW MODAL
    // ==============================
    SpreadsheetApp.getUi()
      .showModalDialog(html, "🚪 Employee Exit");

  } catch (err) {

    SpreadsheetApp.getUi().alert(err.message);

  }

}