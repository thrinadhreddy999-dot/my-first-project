// ==============================
// 🆔 EMPLOYEE ID GENERATOR (FINAL SAFE)
// ==============================
function generateEmployeeId() {

  const lock = LockService.getScriptLock();

  try {

    lock.waitLock(5000);

    const props = PropertiesService.getScriptProperties();
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);

    if (!master) {
      throw new Error("EMPLOYEE_MASTER sheet not found");
    }

    const PREFIX = "TH-EMP-"; // 👉 move to CONFIG later

    // ==============================
    // 📊 EXISTING IDS (FAST MAP)
    // ==============================
    const lastRow = master.getLastRow();
    const existingIds = new Set();

    if (lastRow >= 2) {
      const ids = master.getRange(2,1,lastRow-1,1).getValues();
      ids.forEach(r => {
        if (r[0]) existingIds.add(String(r[0]).trim());
      });
    }

    // ==============================
    // 🚀 COUNTER
    // ==============================
    let counter = parseInt(props.getProperty("EMP_ID_COUNTER")) || 0;

    let attempts = 0;
    let newId = "";

    // ==============================
    // 🔁 SAFE GENERATION LOOP
    // ==============================
    do {

      counter++;
      newId = formatEmployeeId(counter, PREFIX);
      attempts++;

      if (attempts > 10) {
        throw new Error("ID generation conflict loop");
      }

    } while (existingIds.has(newId));

    // ==============================
    // 💾 STORE LAST USED (FIXED)
    // ==============================
    props.setProperty("EMP_ID_COUNTER", counter);

    return newId;

  } catch (err) {

    throw new Error("ID Generation Failed: " + err.message);

  } finally {

    try {
      lock.releaseLock();
    } catch (e) {}

  }

}


// ==============================
// 🎯 FORMAT ID
// ==============================
function formatEmployeeId(num, prefix = "TH-EMP-") {

  return prefix + String(num).padStart(3, "0");

}