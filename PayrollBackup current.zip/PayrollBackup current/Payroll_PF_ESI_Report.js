// ==============================
// 📑 PF & ESI REPORT (FINAL)
// ==============================
function generatePFESIReport() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const payrollSheet = ss.getActiveSheet();

    const sheetName = payrollSheet.getName();

    // ==============================
    // 🛡️ VALIDATE PAYROLL SHEET
    // ==============================
    if (!isPayrollSheet(sheetName)) {
      throw new Error("Not a payroll sheet");
    }

    // ==============================
    // 🔒 FINALIZED CHECK
    // ==============================
    if (payrollSheet.getRange("Z1").getValue() !== "FINALIZED") {
      throw new Error("Finalize payroll before generating report");
    }

    const reportName = "PF_ESI_Report_" + sheetName.replace(" ", "_");

    if (ss.getSheetByName(reportName)) {
      throw new Error("Report already exists.");
    }

    const reportSheet = ss.insertSheet(reportName);

    const lastRow = payrollSheet.getLastRow();
    if (lastRow < 3) throw new Error("No payroll data");

    const totalCols = payrollSheet.getLastColumn();

    const data = payrollSheet
      .getRange(3,1,lastRow-2,totalCols)
      .getValues();

    const c = CONFIG.COLUMNS;

    let totalEmployees = 0;
    let pfEmployees = 0;
    let esiEmployees = 0;

    let totalPF = 0;
    let totalESI = 0;
    let totalPT = 0;
    let totalNet = 0;

    const detailedData = [];

    // ==============================
    // 📊 PROCESS DATA
    // ==============================
    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];
      if (!empId) return;

      const name = row[c.NAME - 1];
      const dept = row[c.DEPARTMENT - 1];

      const gross = Number(row[c.GROSS - 1]) || 0;
      const pf = Number(row[c.PF - 1]) || 0;
      const esi = Number(row[c.ESI - 1]) || 0;
      const pt = Number(row[c.PT - 1]) || 0;
      const net = Number(row[c.NET - 1]) || 0;

      if (net <= 0) return;

      totalEmployees++;

      if (pf > 0) pfEmployees++;
      if (esi > 0) esiEmployees++;

      totalPF += pf;
      totalESI += esi;
      totalPT += pt;
      totalNet += net;

      detailedData.push([
        empId,
        name,
        dept,
        gross,
        pf,
        esi,
        pt,
        net
      ]);

    });

    if (totalEmployees === 0) {
      throw new Error("No valid employee records found");
    }

    // ==============================
    // 🔽 SORT BY NAME
    // ==============================
    detailedData.sort((a,b) => a[1].localeCompare(b[1]));

    // ==============================
    // 📊 SUMMARY
    // ==============================
    reportSheet.getRange(1,1,8,2).setValues([
      ["Metric","Value"],
      ["Total Employees", totalEmployees],
      ["PF Eligible Employees", pfEmployees],
      ["ESI Eligible Employees", esiEmployees],
      ["Total PF", totalPF],
      ["Total ESI", totalESI],
      ["Total Professional Tax", totalPT],
      ["Total Net Salary", totalNet]
    ]);

    // ==============================
    // 📄 DETAILED TABLE
    // ==============================
    reportSheet.getRange(10,1,1,8).setValues([[
      "Employee ID",
      "Name",
      "Department",
      "Gross",
      "PF",
      "ESI",
      "PT",
      "Net Salary"
    ]]);

    reportSheet.getRange(11,1,detailedData.length,8)
      .setValues(detailedData);

    // ==============================
    // 🎨 FORMAT
    // ==============================
    reportSheet.setFrozenRows(10);

    reportSheet.getRange("A1:B1")
      .setFontWeight("bold");

    reportSheet.getRange("A10:H10")
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    // Currency formatting
    reportSheet.getRange(2,2,7,1).setNumberFormat("₹ #,##0");
    reportSheet.getRange(11,4,detailedData.length,5).setNumberFormat("₹ #,##0");

    reportSheet.autoResizeColumns(1,8);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PF_ESI_REPORT_GENERATED",
      sheetName,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("PF & ESI Report generated", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}