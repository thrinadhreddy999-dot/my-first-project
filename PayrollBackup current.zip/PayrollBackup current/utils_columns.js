// ==============================
// ⚡ COLUMN ENGINE (ELITE FINAL)
// ==============================

// Cache
const COLUMN_CACHE = {};


// ==============================
// 🧠 DETECT HEADER ROW
// ==============================
function getHeaderRow(sheet) {

  const name = sheet.getName();

  if (typeof isPayrollSheet === "function" && isPayrollSheet(name)) {
    return 2;
  }

  return 1;
}


// ==============================
// 🔍 BUILD COLUMN MAP
// ==============================
function buildColumnMap(sheet) {

  const headerRow = getHeaderRow(sheet);
  const lastCol = sheet.getLastColumn();

  if (lastCol === 0) {
    throw new Error(`No columns found in sheet: ${sheet.getName()}`);
  }

  const headers = sheet
    .getRange(headerRow, 1, 1, lastCol)
    .getValues()[0];

  if (!headers || headers.length === 0) {
    throw new Error(`Header row empty in sheet: ${sheet.getName()}`);
  }

  const map = {};

  headers.forEach((h, i) => {

    if (h) {
      map[h.toString().trim().toLowerCase()] = i + 1;
    }

  });

  return map;
}


// ==============================
// 🔍 GET COLUMN INDEX
// ==============================
function getColumnIndex(sheet, columnName) {

  if (!sheet) {
    throw new Error(`Sheet not provided for column: ${columnName}`);
  }

  if (!columnName) {
    throw new Error("Column name is required");
  }

  const sheetName = sheet.getName();

  // ==============================
  // CACHE BUILD
  // ==============================
  if (!COLUMN_CACHE[sheetName]) {
    COLUMN_CACHE[sheetName] = buildColumnMap(sheet);
  }

  const target = columnName.toString().trim().toLowerCase();
  const colIndex = COLUMN_CACHE[sheetName][target];

  if (!colIndex) {

    if (CONFIG.SYSTEM.DEBUG) {
      Logger.log(`❌ Column not found: ${columnName} in ${sheetName}`);
      Logger.log("Available:", Object.keys(COLUMN_CACHE[sheetName]));
    }

    throw new Error(`Column not found: "${columnName}" in "${sheetName}"`);
  }

  return colIndex;
}


// ==============================
// 🔄 RESET CACHE
// ==============================
function resetColumnCache(sheetName = null) {

  if (sheetName) {
    delete COLUMN_CACHE[sheetName];
  } else {
    Object.keys(COLUMN_CACHE).forEach(k => delete COLUMN_CACHE[k]);
  }

}


// ==============================
// 🔍 GET FULL COLUMN MAP
// ==============================
function getColumnMap(sheet) {

  const sheetName = sheet.getName();

  if (!COLUMN_CACHE[sheetName]) {
    COLUMN_CACHE[sheetName] = buildColumnMap(sheet);
  }

  return COLUMN_CACHE[sheetName];
}


// ==============================
// 📜 CENTRAL LOGGING ENGINE (OPTIMIZED)
// ==============================
function logAction(action, ref, user) {

  try {

    if (CONFIG.SYSTEM.LOG_LEVEL === "ERROR") return;

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    let logSheet = ss.getSheetByName(CONFIG.SHEETS.SYSTEM_LOG);

    if (!logSheet) {
      logSheet = ss.insertSheet(CONFIG.SHEETS.SYSTEM_LOG);
      logSheet.getRange(1,1,1,4).setValues([
        ["Timestamp","Action","Reference","User"]
      ]);
    }

    const nextRow = logSheet.getLastRow() + 1;

    logSheet.getRange(nextRow,1,1,4).setValues([[
      new Date(),
      action,
      ref,
      user
    ]]);

  } catch (err) {

    if (CONFIG.SYSTEM.DEBUG) {
      Logger.log("Log Error: " + err.message);
    }

  }

}