// ==============================
// 📧 PAYSLIP EMAIL ENGINE (FINAL SAFE)
// ==============================
function sendPayslipsEmail() {

  try {

    requireAdminAccess(); // 🔒 ADMIN ONLY

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const payrollSheet = ss.getActiveSheet();
    const empSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

    if (!empSheet) {
      throw new Error("EMPLOYEE_DETAILS sheet not found.");
    }

    // ==============================
    // 🔒 FINALIZATION CHECK
    // ==============================
    if (payrollSheet.getRange("Z1").getValue() !== "FINALIZED") {
      throw new Error("Payroll not finalized");
    }

    const month = payrollSheet.getName();
    const c = CONFIG.COLUMNS;

    // ==============================
    // 📁 GET MONTH FOLDER (FIXED)
    // ==============================
    const parent = DriveApp.getFoldersByName("Town_Payroll_Payslips");

    if (!parent.hasNext()) {
      throw new Error("Payslip folder not found");
    }

    const parentFolder = parent.next();

    const subFolders = parentFolder.getFoldersByName(month.replace(" ","_"));

    if (!subFolders.hasNext()) {
      throw new Error("Month folder not found");
    }

    const folder = subFolders.next();

    // ==============================
    // 📌 COLUMN INDEXES
    // ==============================
    const empIdCol = getColumnIndex(empSheet, CONFIG.DETAILS_COLUMNS.EMP_ID);
    const emailCol = getColumnIndex(empSheet, CONFIG.DETAILS_COLUMNS.EMAIL);

    const empData = empSheet.getDataRange().getValues();

    const emailMap = {};

    for (let i = 1; i < empData.length; i++) {

      const id = empData[i][empIdCol - 1];
      const email = String(empData[i][emailCol - 1] || "").trim();

      if (id && email && email.includes("@")) {
        emailMap[id] = email;
      }
    }

    // ==============================
    // 📊 PAYROLL DATA
    // ==============================
    const lastRow = payrollSheet.getLastRow();
    if (lastRow < 3) return;

    const payrollData = payrollSheet
      .getRange(3,1,lastRow-2,20)
      .getValues();

    let sent = 0;
    let skipped = 0;

    // ==============================
    // 🚀 SEND EMAILS
    // ==============================
    payrollData.forEach(row => {

      try {

        const empId = row[c.EMP_ID - 1];
        if (!empId) return;

        const name = row[c.NAME - 1];
        const status = row[c.STATUS - 1];
        const net = row[c.NET - 1];

        if (
          status !== CONFIG.PAYMENT_STATUS.PAID ||
          !net ||
          net === 0
        ) {
          skipped++;
          return;
        }

        const email = emailMap[empId];

        if (!email) {
          skipped++;
          return;
        }

        const fileName = `Payslip_${month}_${empId}.pdf`;
        const files = folder.getFilesByName(fileName);

        if (!files.hasNext()) {
          skipped++;
          return;
        }

        const file = files.next();

        // ==============================
        // 📧 EMAIL CONTENT
        // ==============================
        const subject = `Salary Slip – ${month}`;

        const body = `
Dear ${name},

Please find attached your salary slip for ${month}.

Regards,
Town Hospitals
Accounts Department
        `;

        MailApp.sendEmail({
          to: email,
          subject: subject,
          body: body,
          attachments: [file.getBlob()]
        });

        sent++;

      } catch (innerErr) {
        skipped++;
      }

    });

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYSLIPS_EMAILED",
      `Sent: ${sent}, Skipped: ${skipped}`,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet().toast(
      `Emails Sent: ${sent}`,
      "Success",
      4
    );

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}