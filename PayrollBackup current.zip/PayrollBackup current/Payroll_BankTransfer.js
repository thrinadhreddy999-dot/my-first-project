// ==============================
// 💳 BANK TRANSFER GENERATOR (FINAL)
// ==============================
function generateBankTransferSheet() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const payrollSheet = ss.getActiveSheet();
    const employeeSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

    if (!employeeSheet) {
      throw new Error("EMPLOYEE_DETAILS sheet not found.");
    }

    const sheetName = payrollSheet.getName();

    // ==============================
    // 🛡️ VALIDATE PAYROLL SHEET
    // ==============================
    if (!isPayrollSheet(sheetName)) {
      throw new Error("Not a payroll sheet");
    }

    // ==============================
    // 🔒 FINALIZED CHECK
    // ==============================
    if (payrollSheet.getRange("Z1").getValue() !== "FINALIZED") {
      throw new Error("Payroll must be finalized before bank export");
    }

    const bankSheetName = "Bank_Salary_" + sheetName.replace(" ", "_");

    if (ss.getSheetByName(bankSheetName)) {
      throw new Error("Bank sheet already exists.");
    }

    const bankSheet = ss.insertSheet(bankSheetName);

    // ==============================
    // 📊 DATA FETCH
    // ==============================
    const lastRow = payrollSheet.getLastRow();
    if (lastRow < 3) throw new Error("No payroll data found");

    const totalCols = payrollSheet.getLastColumn();

    const payrollData = payrollSheet
      .getRange(3,1,lastRow-2,totalCols)
      .getValues();

    const employeeData = employeeSheet.getDataRange().getValues();

    const c = CONFIG.COLUMNS;

    const empIdCol = getColumnIndex(employeeSheet, CONFIG.DETAILS_COLUMNS.EMP_ID);
    const accountCol = getColumnIndex(employeeSheet, CONFIG.DETAILS_COLUMNS.ACCOUNT);
    const ifscCol = getColumnIndex(employeeSheet, CONFIG.DETAILS_COLUMNS.IFSC);

    // ==============================
    // 🔍 BUILD LOOKUP MAP
    // ==============================
    const empMap = {};

    for (let i = 1; i < employeeData.length; i++) {

      const emp = employeeData[i];
      const id = emp[empIdCol - 1];

      if (!id) continue;

      empMap[id] = {
        account: String(emp[accountCol - 1] || "").trim(),
        ifsc: String(emp[ifscCol - 1] || "").trim()
      };
    }

    // ==============================
    // 🧾 BUILD OUTPUT
    // ==============================
    const output = [];
    const missingBank = [];

    payrollData.forEach(row => {

      const empId = row[c.EMP_ID - 1];
      if (!empId) return;

      const status = row[c.STATUS - 1];

      // ✅ ONLY PAID
      if (status !== CONFIG.PAYMENT_STATUS.PAID) return;

      const name = row[c.NAME - 1];
      const netSalary = Number(row[c.NET - 1]) || 0;

      if (netSalary <= 0) return;

      const details = empMap[empId];

      if (!details || !details.account || !details.ifsc) {
        missingBank.push(name || empId);
        return;
      }

      output.push([
        name,
        details.account,
        details.ifsc,
        netSalary
      ]);

    });

    if (output.length === 0) {
      throw new Error("No valid PAID employees found");
    }

    // ==============================
    // 🔽 SORT (BY NAME)
    // ==============================
    output.sort((a,b) => a[0].localeCompare(b[0]));

    // ==============================
    // 📥 WRITE
    // ==============================
    bankSheet.getRange(1,1,1,4).setValues([
      ["Employee Name","Account Number","IFSC Code","Net Salary"]
    ]);

    bankSheet.getRange(2,1,output.length,4).setValues(output);

    // ==============================
    // 🎨 FORMAT
    // ==============================
    bankSheet.setFrozenRows(1);

    bankSheet.getRange(1,1,1,4)
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    bankSheet.getRange(2,4,output.length,1)
      .setNumberFormat("₹ #,##0");

    bankSheet.autoResizeColumns(1,4);

    // ==============================
    // ⚠️ MISSING BANK ALERT
    // ==============================
    if (missingBank.length > 0) {
      SpreadsheetApp.getUi().alert(
        "⚠️ Missing bank details for:\n" +
        missingBank.slice(0,10).join("\n") +
        (missingBank.length > 10 ? "\n...more" : "")
      );
    }

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "BANK_TRANSFER_GENERATED",
      `${sheetName} | Records: ${output.length}`,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("Bank transfer sheet created", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}