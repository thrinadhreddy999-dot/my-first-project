function exitEmployeeById(empId, exitDate, reason) {

  const lock = LockService.getScriptLock();

  try {

    lock.waitLock(10000);

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const history = ss.getSheetByName(CONFIG.SHEETS.EMPLOYMENT_HISTORY);

    if (!master || !history) {
      throw new Error("Required sheets missing");
    }

    const user = Session.getEffectiveUser().getEmail();

    // ==============================
    // 🧹 CLEAN INPUT
    // ==============================
    empId = String(empId || "").trim();
    if (!empId) throw new Error("Employee ID required");

    if (!exitDate) throw new Error("Exit date required");

    const parsedExit = new Date(exitDate);
    if (isNaN(parsedExit)) throw new Error("Invalid exit date");

    const today = new Date();
    if (parsedExit > today) {
      throw new Error("Exit date cannot be in future");
    }

    // ==============================
    // 🔍 FIND EMPLOYEE
    // ==============================
    const data = master.getDataRange().getValues();

    let rowIndex = -1;

    for (let i = 1; i < data.length; i++) {
      if (String(data[i][0]).trim() === empId) {
        rowIndex = i + 1;
        break;
      }
    }

    if (rowIndex === -1) {
      throw new Error("Employee not found");
    }

    const statusCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.STATUS);
    const leftCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.LEFT_DATE);
    const dojCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.DOJ);

    const currentStatus = master.getRange(rowIndex, statusCol).getValue();
    const doj = new Date(master.getRange(rowIndex, dojCol).getValue());

    // ==============================
    // 🚫 VALIDATIONS
    // ==============================
    if (![CONFIG.STATUS.ACTIVE, CONFIG.STATUS.PROBATION].includes(currentStatus)) {
      throw new Error("Employee already inactive");
    }

    if (parsedExit < doj) {
      throw new Error("Exit date before DOJ not allowed");
    }

    const validReasons = [
      CONFIG.STATUS.RESIGNED,
      CONFIG.STATUS.TERMINATED,
      CONFIG.STATUS.ABSCONDED,
      CONFIG.STATUS.CONTRACT_COMPLETED
    ];

    const finalReason = validReasons.includes(reason)
      ? reason
      : CONFIG.STATUS.RESIGNED;

    // ==============================
    // ✅ ATOMIC UPDATE
    // ==============================
    master.getRange(rowIndex, statusCol, 1, 2).setValues([[
      finalReason,
      parsedExit
    ]]);

    // ==============================
    // 🧾 HISTORY
    // ==============================
    history.appendRow([
      empId,
      "",
      parsedExit,
      "Inactive",
      finalReason,
      user
    ]);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction("EMPLOYEE_EXITED", empId, user);

    ss.toast("Employee exited successfully", "Success", 3);

    updateHRDashboard();

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);
    throw err;

  } finally {

    lock.releaseLock();

  }

}