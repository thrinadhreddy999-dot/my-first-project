// ==============================
// 💾 SMART BACKUP ENGINE (FINAL SAFE)
// ==============================
function backupPayrollSystem(e) {

  const lock = LockService.getScriptLock();

  try {

    lock.waitLock(10000);

    requireAdminAccess();

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const file = DriveApp.getFileById(ss.getId());
    const user = Session.getEffectiveUser().getEmail();

    const folderName = "Town_Payroll_Backups";

    // ==============================
    // 📂 SAFE FOLDER (UNIQUE)
    // ==============================
    let folder;

    const folders = DriveApp.getFoldersByName(folderName);

    if (folders.hasNext()) {
      folder = folders.next();
    } else {
      folder = DriveApp.createFolder(folderName);
    }

    // ==============================
    // 🕒 TIMESTAMP
    // ==============================
    const timestamp = Utilities.formatDate(
      new Date(),
      Session.getScriptTimeZone(),
      "yyyy-MM-dd_HH-mm-ss"
    );

    const backupName = `TH_PAYROLL_BACKUP_${timestamp}`;

    // ==============================
    // 🔁 RETRY COPY
    // ==============================
    let newFile;

    for (let i = 0; i < 3; i++) {
      try {
        newFile = file.makeCopy(backupName, folder);
        if (newFile) break;
      } catch (err) {
        Utilities.sleep(1000);
      }
    }

    if (!newFile) {
      throw new Error("Backup creation failed after retries");
    }

    // ==============================
    // 🔐 MAKE READ-ONLY
    // ==============================
    newFile.setSharing(
      DriveApp.Access.PRIVATE,
      DriveApp.Permission.VIEW
    );

    // ==============================
    // 🧪 VALIDATE BACKUP
    // ==============================
    if (!newFile.getId()) {
      throw new Error("Backup file invalid");
    }

    // ==============================
    // 🧹 CLEAN OLD (SAFE LIMIT)
    // ==============================
    const files = folder.getFiles();
    const backups = [];

    while (files.hasNext()) {

      const f = files.next();

      if (f.getName().startsWith("TH_PAYROLL_BACKUP_")) {
        backups.push(f);
      }

    }

    backups.sort((a,b)=> b.getDateCreated() - a.getDateCreated());

    for (let i = 10; i < backups.length; i++) {
      try {
        backups[i].setTrashed(true);
      } catch (err) {}
    }

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "BACKUP_CREATED",
      backupName,
      user
    );

    if (!e) {
      SpreadsheetApp.getActiveSpreadsheet()
        .toast("Backup created successfully", "Success", 3);
    }

  } catch (error) {

    Logger.log("Backup Error: " + error.message);

    if (!e) {
      SpreadsheetApp.getUi().alert("❌ Backup failed:\n" + error.message);
    }

  } finally {

    try {
      lock.releaseLock();
    } catch (e) {}

  }

}