function protectPayrollSheet(sheet) {

  const lock = LockService.getScriptLock();

  try {

    lock.waitLock(10000);

    if (!sheet) throw new Error("Sheet not provided");

    const sheetName = sheet.getName();
    if (!isPayrollSheet(sheetName)) return;

    const user = Session.getEffectiveUser().getEmail();
    const admins = CONFIG.ADMINS || [];

    if (!admins.includes(user)) {
      throw new Error("Unauthorized access to protection");
    }

    const lastRow = sheet.getLastRow();
    if (lastRow < 3) return;

    const c = CONFIG.COLUMNS;

    // ==============================
    // 🧹 REMOVE OLD PROTECTION (SAFE)
    // ==============================
    const protections = sheet.getProtections(SpreadsheetApp.ProtectionType.SHEET);
    protections.forEach(p => {
      if (p.getDescription() === "SMART PAYROLL PROTECTION") {
        p.remove();
      }
    });

    // ==============================
    // 🔒 CREATE PROTECTION
    // ==============================
    const protection = sheet.protect()
      .setDescription("SMART PAYROLL PROTECTION");

    protection.removeEditors(protection.getEditors());

    admins.forEach(email => {
      if (email) protection.addEditor(email);
    });

    if (protection.canDomainEdit()) {
      protection.setDomainEdit(false);
    }

    // ==============================
    // 🚨 FINALIZED LOCK (STRONG)
    // ==============================
    const finalized = sheet.getRange("Z1").getValue() === "FINALIZED";

    if (finalized) {

      protection.setUnprotectedRanges([]);

      logAction("PAYROLL_HARD_LOCK", sheetName, user);
      return;
    }

    // ==============================
    // ✍️ SAFE EDITABLE RANGES
    // ==============================
    const editableCols = [
      c.PRESENT_DAYS,
      c.SALARY_DAYS,
      c.INCENTIVE,
      c.ADVANCE,
      c.HOSPITAL_DEDUCTION,
      c.PENALTY,
      c.LEAVE_DEDUCTION,
      c.STATUS,
      c.REMARKS
    ];

    // Validate columns
    editableCols.forEach(col => {
      if (!col || col <= 0) {
        throw new Error("Invalid column configuration");
      }
    });

    const editableRanges = editableCols.map(col =>
      sheet.getRange(3, col, sheet.getMaxRows() - 2, 1) // 🔥 dynamic safe
    );

    protection.setUnprotectedRanges(editableRanges);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYROLL_PROTECTED",
      sheetName + " | EditableCols: " + editableCols.join(","),
      user
    );

  } catch (err) {

    Logger.log("Protection Error: " + err.message);
    throw err;

  } finally {

    lock.releaseLock();

  }

}