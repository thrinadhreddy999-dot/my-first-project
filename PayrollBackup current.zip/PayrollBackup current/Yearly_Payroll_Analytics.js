// ==============================
// 📅 YEARLY PAYROLL ANALYTICS (FINAL)
// ==============================
function generateYearlyPayrollAnalytics() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheets = ss.getSheets();

    let analyticsSheet = ss.getSheetByName("YEARLY_PAYROLL_ANALYTICS");

    if (!analyticsSheet) {
      analyticsSheet = ss.insertSheet("YEARLY_PAYROLL_ANALYTICS");
    }

    const c = CONFIG.COLUMNS;

    const monthOrder = {
      January:1, February:2, March:3, April:4, May:5, June:6,
      July:7, August:8, September:9, October:10, November:11, December:12
    };

    const currentYear = new Date().getFullYear();

    const results = [];

    // ==============================
    // 📊 PROCESS SHEETS
    // ==============================
    sheets.forEach(sheet => {

      const name = sheet.getName();

      if (!isPayrollSheet(name)) return;

      // Parse month/year
      const parts = name.split(" ");
      const month = parts[0];
      const year = parseInt(parts[1]);

      // Only current year
      if (year !== currentYear) return;

      // FINALIZED CHECK
      if (sheet.getRange("Z1").getValue() !== "FINALIZED") return;

      const lastRow = sheet.getLastRow();
      if (lastRow < 3) return;

      const data = sheet
        .getRange(3, c.NET, lastRow-2, 1)
        .getValues();

      let totalSalary = 0;

      data.forEach(row => {
        totalSalary += Number(row[0]) || 0;
      });

      results.push([month, year, totalSalary]);

    });

    if (results.length === 0) {
      throw new Error("No yearly payroll data found");
    }

    // ==============================
    // 🔽 SORT CHRONOLOGICALLY
    // ==============================
    results.sort((a,b) => {

      if (a[1] !== b[1]) return a[1] - b[1];

      return monthOrder[a[0]] - monthOrder[b[0]];
    });

    // ==============================
    // 🧹 CLEAR
    // ==============================
    analyticsSheet.getRange(1,1,100,10).clearContent().clearFormat();

    // ==============================
    // 📊 HEADER
    // ==============================
    analyticsSheet.getRange(1,1,1,2).setValues([
      ["Month","Total Salary"]
    ]);

    analyticsSheet.getRange(1,1,1,2)
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    // ==============================
    // 📥 DATA
    // ==============================
    const finalData = results.map(r => [`${r[0]} ${r[1]}`, r[2]]);

    analyticsSheet.getRange(2,1,finalData.length,2)
      .setValues(finalData);

    // ==============================
    // 💰 FORMAT
    // ==============================
    analyticsSheet.getRange(2,2,finalData.length,1)
      .setNumberFormat("₹ #,##0");

    analyticsSheet.setFrozenRows(1);

    // ==============================
    // 📊 CHART
    // ==============================
    const charts = analyticsSheet.getCharts();
    charts.forEach(chart => analyticsSheet.removeChart(chart));

    const chart = analyticsSheet.newChart()
      .setChartType(Charts.ChartType.LINE)
      .addRange(analyticsSheet.getRange(1,1,finalData.length+1,2))
      .setPosition(2,4,0,0)
      .setOption("title", "Monthly Salary Trend")
      .setOption("legend", { position: "bottom" })
      .build();

    analyticsSheet.insertChart(chart);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "YEARLY_ANALYTICS_GENERATED",
      currentYear,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("Yearly analytics generated", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}