// ==============================
// 🔒 PAYROLL SAFETY ENGINE (FINAL)
// ==============================
function payrollSafetyCheck() {

  const sheet = SpreadsheetApp.getActiveSheet();
  const sheetName = sheet.getName();
  const c = CONFIG.COLUMNS;

  // ==============================
  // 🛡️ VALIDATE SHEET
  // ==============================
  if (!isPayrollSheet(sheetName)) {
    throw new Error("❌ Not a payroll sheet.");
  }

  const lastRow = sheet.getLastRow();
  const lastCol = sheet.getLastColumn();

  if (lastRow < 3) return true;

  // ==============================
  // 🚫 SAFETY LIMIT
  // ==============================
  if (lastRow > (CONFIG.SYSTEM.MAX_ROWS || 5000)) {
    throw new Error("Sheet too large. Cannot validate.");
  }

  // ==============================
  // 📊 SAFE DATA READ
  // ==============================
  const data = sheet.getRange(3,1,lastRow-2,lastCol).getValues();

  // ==============================
  // 🧹 CLEAR OLD HIGHLIGHTS
  // ==============================
  sheet.getRange(3,1,lastRow-2,lastCol).setBackground(null);

  const errors = new Set();
  const errorMatrix = [];

  // ==============================
  // 📅 MONTH VALIDATION
  // ==============================
  const parts = sheetName.split(" ");

  if (parts.length < 2) {
    throw new Error("❌ Invalid sheet name format.");
  }

  const parsed = new Date(Date.parse(parts[0] + " 1, " + parts[1]));
  if (isNaN(parsed)) {
    throw new Error("❌ Invalid month/year in sheet name.");
  }

  const daysInMonth = new Date(
    parsed.getFullYear(),
    parsed.getMonth() + 1,
    0
  ).getDate();

  // ==============================
  // 🔍 VALIDATION LOOP
  // ==============================
  for (let i = 0; i < data.length; i++) {

    const row = data[i];
    const rowNumber = i + 3;

    const empId = row[c.EMP_ID - 1];

    // Skip department rows
    if (!empId) {
      errorMatrix.push(new Array(lastCol).fill(null));
      continue;
    }

    let rowErrors = false;
    const rowColors = new Array(lastCol).fill(null);

    const monthlySalary = Number(row[c.MONTHLY_SALARY - 1]) || 0;
    const presentDays = Number(row[c.PRESENT_DAYS - 1]) || 0;
    const salaryDays = Number(row[c.SALARY_DAYS - 1]) || 0;
    const incentive = Number(row[c.INCENTIVE - 1]) || 0;
    const advance = Number(row[c.ADVANCE - 1]) || 0;
    const status = row[c.STATUS - 1];

    // ==============================
    // VALIDATIONS
    // ==============================

    if (monthlySalary <= 0) {
      errors.add(`Row ${rowNumber}: Invalid Salary`);
      rowColors[c.MONTHLY_SALARY - 1] = CONFIG.COLORS.HOLD;
      rowErrors = true;
    }

    if (presentDays < 0 || presentDays > daysInMonth) {
      errors.add(`Row ${rowNumber}: Invalid Present Days`);
      rowColors[c.PRESENT_DAYS - 1] = CONFIG.COLORS.HOLD;
      rowErrors = true;
    }

    if (salaryDays < 0) {
      errors.add(`Row ${rowNumber}: Invalid Salary Days`);
      rowColors[c.SALARY_DAYS - 1] = CONFIG.COLORS.HOLD;
      rowErrors = true;
    }

    if (incentive < 0 || advance < 0) {
      errors.add(`Row ${rowNumber}: Negative values not allowed`);
      rowColors[c.INCENTIVE - 1] = CONFIG.COLORS.HOLD;
      rowErrors = true;
    }

    if (!CONFIG.VALIDATION.PAYMENT_STATUS.includes(status)) {
      errors.add(`Row ${rowNumber}: Invalid Payment Status`);
      rowColors[c.STATUS - 1] = CONFIG.COLORS.HOLD;
      rowErrors = true;
    }

    errorMatrix.push(rowColors);

  }

  // ==============================
  // 🎨 APPLY HIGHLIGHT (BATCH)
  // ==============================
  sheet.getRange(3,1,errorMatrix.length,lastCol).setBackgrounds(errorMatrix);

  // ==============================
  // ❌ THROW ERROR
  // ==============================
  if (errors.size > 0) {

    const errorList = Array.from(errors);

    const message =
      "🚫 PAYROLL VALIDATION FAILED\n\n" +
      errorList.slice(0,10).join("\n") +
      (errorList.length > 10 ? "\n...more errors" : "");

    throw new Error(message);
  }

  return true;

}