function safeExecute(fnName, fn) {
  try {
    logAction("START", fnName + " started");

    const result = fn();

    logAction("SUCCESS", fnName + " completed");
    return result;

  } catch (error) {
    logAction("ERROR", fnName + " failed: " + error.message);

    SpreadsheetApp.getUi().alert(
      "❌ Error in " + fnName + ":\n\n" + error.message
    );

    throw error;
  }
}