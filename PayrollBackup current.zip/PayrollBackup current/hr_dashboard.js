function updateHRDashboard() {

  const ss = SpreadsheetApp.getActiveSpreadsheet();
  const master = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
  const dash = ss.getSheetByName("HR_DASHBOARD");

  if (!master || !dash) return;

  const masterData = master.getDataRange().getValues();

  const statusCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.STATUS);
  const dojCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.DOJ);
  const leftCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.LEFT_DATE);
  const deptCol = getColumnIndex(master, CONFIG.MASTER_COLUMNS.DEPARTMENT);

  let total = 0;
  let active = 0;
  let inactive = 0;
  let joins = 0;
  let exits = 0;

  const deptCount = {};

  const today = new Date();
  const month = today.getMonth();
  const year = today.getFullYear();

  for (let i = 1; i < masterData.length; i++) {

    const status = masterData[i][statusCol - 1];
    const doj = masterData[i][dojCol - 1];
    const left = masterData[i][leftCol - 1];
    const dept = masterData[i][deptCol - 1];

    if (!status) continue;

    total++;

    if (
      status === CONFIG.STATUS.ACTIVE ||
      status === CONFIG.STATUS.PROBATION
    ) {
      active++;

      if (dept) {
        deptCount[dept] = (deptCount[dept] || 0) + 1;
      }

    } else {
      inactive++;
    }

    if (doj) {
      const d = new Date(doj);
      if (!isNaN(d) && d.getMonth() === month && d.getFullYear() === year) {
        joins++;
      }
    }

    if (left) {
      const l = new Date(left);
      if (!isNaN(l) && l.getMonth() === month && l.getFullYear() === year) {
        exits++;
      }
    }

  }

  // ==============================
  // KPI VALUES
  // ==============================
  dash.getRange("B2").setValue(total);
  dash.getRange("B3").setValue(active);
  dash.getRange("B4").setValue(inactive);
  dash.getRange("B5").setValue(joins);
  dash.getRange("B6").setValue(exits);

  // ==============================
  // KPI COLORS
  // ==============================
  dash.getRange("B2").setBackground("#e3f2fd");
  dash.getRange("B3").setBackground("#d9ead3");
  dash.getRange("B4").setBackground("#f4cccc");
  dash.getRange("B5").setBackground("#fff2cc");
  dash.getRange("B6").setBackground("#fce5cd");

  // ==============================
  // DEPARTMENT TABLE
  // ==============================
  const startRow = 10;

  dash.getRange(startRow, 1, dash.getMaxRows(), 2).clearContent();

  const deptData = Object.entries(deptCount)
    .sort((a, b) => b[1] - a[1]);

  if (deptData.length > 0) {
    dash.getRange(startRow, 1, deptData.length, 2)
      .setValues(deptData);
  }

  // ==============================
  // FORMAT
  // ==============================
  dash.getRange("A1:B1").merge();
  dash.getRange("A1")
    .setFontSize(16)
    .setFontWeight("bold")
    .setHorizontalAlignment("center");

  dash.getRange("A2:A6").setFontWeight("bold");
  dash.getRange("A9:B9").setFontWeight("bold").setBackground("#d6e4f0");

  dash.autoResizeColumns(1, 2);

  // ==============================
  // 📊 CREATE / REFRESH CHART
  // ==============================
  createDepartmentChart(dash, deptData.length);
}


// ==============================
// 📊 CHART FUNCTION
// ==============================
function createDepartmentChart(sheet, rowCount) {

  if (rowCount === 0) return;

  // Remove old charts
  const charts = sheet.getCharts();
  charts.forEach(chart => sheet.removeChart(chart));

  const range = sheet.getRange(10, 1, rowCount, 2);

  const chart = sheet.newChart()
    .setChartType(Charts.ChartType.COLUMN)
    .addRange(range)
    .setPosition(10, 4, 0, 0)
    .setOption("title", "Department-wise Employees")
    .setOption("legend", { position: "none" })
    .build();

  sheet.insertChart(chart);
}