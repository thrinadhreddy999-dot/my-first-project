// ==============================
// 🚨 HR ALERT SYSTEM (FINAL)
// ==============================
function generateHRAlerts() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const empSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const detailsSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

    if (!empSheet || !detailsSheet) {
      throw new Error("Required sheets missing");
    }

    let alertSheet = ss.getSheetByName("HR_ALERTS");

    if (!alertSheet) {
      alertSheet = ss.insertSheet("HR_ALERTS");
    }

    // Safe clear
    alertSheet.getRange(1,1,200,10).clearContent().clearFormat();

    const empData = empSheet.getDataRange().getValues();
    const detailsData = detailsSheet.getDataRange().getValues();

    // ==============================
    // 📌 MASTER COLUMNS
    // ==============================
    const empIdCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.EMP_ID);
    const firstCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.FIRST_NAME);
    const lastCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.LAST_NAME);
    const statusCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.STATUS);

    // ==============================
    // 📌 DETAILS COLUMNS
    // ==============================
    const dEmpIdCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.EMP_ID);
    const mobileCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.MOBILE);
    const emailCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.EMAIL);
    const pfCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.PF);
    const esiCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.ESI);

    // ==============================
    // 🔍 DETAILS MAP
    // ==============================
    const detailsMap = {};

    for (let i=1;i<detailsData.length;i++){
      const row = detailsData[i];
      const id = row[dEmpIdCol - 1];

      if (!id) continue;

      detailsMap[id] = {
        mobile: row[mobileCol - 1],
        email: row[emailCol - 1],
        pf: row[pfCol - 1],
        esi: row[esiCol - 1]
      };
    }

    const alerts = [];

    // ==============================
    // 📊 PROCESS
    // ==============================
    for (let i = 1; i < empData.length; i++) {

      const row = empData[i];

      const id = row[empIdCol - 1];
      const first = row[firstCol - 1];
      const last = row[lastCol - 1];
      const status = row[statusCol - 1];

      if (!id || !first || !last) continue;

      // Include ACTIVE + PROBATION
      if (![CONFIG.STATUS.ACTIVE, CONFIG.STATUS.PROBATION].includes(status)) continue;

      const details = detailsMap[id] || {};

      const mobile = details.mobile;
      const email = details.email;
      const pf = details.pf;
      const esi = details.esi;

      const name = (last + " " + first).toUpperCase();

      if (!mobile) {
        alerts.push([id, name, "Missing Mobile", "HIGH", "Employee contact missing"]);
      }

      if (!email) {
        alerts.push([id, name, "Missing Email", "MEDIUM", "Payslip cannot be sent"]);
      }

      if (!pf) {
        alerts.push([id, name, "Missing PF Number", "HIGH", "PF compliance pending"]);
      }

      if (!esi) {
        alerts.push([id, name, "Missing ESI Number", "HIGH", "ESI compliance pending"]);
      }
    }

    if (alerts.length === 0) {
      throw new Error("No alerts found");
    }

    // ==============================
    // 🔽 SORT BY SEVERITY
    // ==============================
    const priority = { HIGH: 1, MEDIUM: 2 };

    alerts.sort((a,b)=> priority[a[3]] - priority[b[3]]);

    // ==============================
    // 📥 WRITE
    // ==============================
    const output = [
      ["Employee ID","Employee Name","Issue","Severity","Details"],
      ...alerts
    ];

    alertSheet.getRange(1,1,output.length,5).setValues(output);

    // ==============================
    // 🎨 FORMAT
    // ==============================
    alertSheet.setFrozenRows(1);

    alertSheet.getRange("A1:E1")
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    alertSheet.autoResizeColumns(1,5);

    // ==============================
    // 🎯 CONDITIONAL COLORS
    // ==============================
    const range = alertSheet.getRange(2,4,alerts.length,1);

    const rules = [
      SpreadsheetApp.newConditionalFormatRule()
        .whenTextEqualTo("HIGH")
        .setBackground(CONFIG.COLORS.HOLD)
        .setRanges([range])
        .build(),

      SpreadsheetApp.newConditionalFormatRule()
        .whenTextEqualTo("MEDIUM")
        .setBackground(CONFIG.COLORS.PENDING)
        .setRanges([range])
        .build()
    ];

    alertSheet.setConditionalFormatRules(rules);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "HR_ALERTS_GENERATED",
      `Total Alerts: ${alerts.length}`,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("HR alerts generated", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}