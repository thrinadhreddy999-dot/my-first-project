// ==============================
// 📊 PF & ESI TRACKER (FINAL)
// ==============================
function updatePFESITracker(){

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();

    const empSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_MASTER);
    const detailsSheet = ss.getSheetByName(CONFIG.SHEETS.EMPLOYEE_DETAILS);

    if (!empSheet || !detailsSheet) {
      throw new Error("Required sheets missing");
    }

    let tracker = ss.getSheetByName("PF_ESI_TRACKER");

    if(!tracker){
      tracker = ss.insertSheet("PF_ESI_TRACKER");
    }

    // Safe clear
    tracker.getRange(1,1,200,10).clearContent().clearFormat();

    const data = empSheet.getDataRange().getValues();
    const detailsData = detailsSheet.getDataRange().getValues();

    const today = new Date();

    // ==============================
    // 📌 MASTER COLUMNS
    // ==============================
    const empIdCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.EMP_ID);
    const firstCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.FIRST_NAME);
    const lastCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.LAST_NAME);
    const dojCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.DOJ);
    const statusCol = getColumnIndex(empSheet, CONFIG.MASTER_COLUMNS.STATUS);

    // ==============================
    // 📌 DETAILS COLUMNS
    // ==============================
    const dEmpIdCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.EMP_ID);
    const pfCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.PF);
    const esiCol = getColumnIndex(detailsSheet, CONFIG.DETAILS_COLUMNS.ESI);

    // ==============================
    // 🔍 BUILD DETAILS MAP
    // ==============================
    const detailsMap = {};

    for (let i=1; i<detailsData.length; i++){
      const row = detailsData[i];
      const id = row[dEmpIdCol - 1];

      if (!id) continue;

      detailsMap[id] = {
        pf: row[pfCol - 1],
        esi: row[esiCol - 1]
      };
    }

    const output = [];

    output.push([
      "Employee ID",
      "Employee Name",
      "Join Date",
      "Months Completed",
      "PF Number",
      "ESI Number",
      "Status"
    ]);

    // ==============================
    // 📊 PROCESS
    // ==============================
    for(let i=1;i<data.length;i++){

      const row = data[i];

      const id = row[empIdCol - 1];
      const first = row[firstCol - 1];
      const last = row[lastCol - 1];
      const joinDateRaw = row[dojCol - 1];
      const empStatus = row[statusCol - 1];

      // Skip inactive
      if (!id || !joinDateRaw) continue;
      if (![CONFIG.STATUS.ACTIVE, CONFIG.STATUS.PROBATION].includes(empStatus)) continue;

      const joinDate = new Date(joinDateRaw);
      if (isNaN(joinDate)) continue;

      const details = detailsMap[id] || {};

      const pf = details.pf || "";
      const esi = details.esi || "";

      const name = (last + " " + first).toUpperCase();

      const diffMonths =
        (today.getFullYear()-joinDate.getFullYear())*12 +
        (today.getMonth()-joinDate.getMonth());

      let status = "";

      if(pf && esi){
        status = "Completed";
      }
      else if(diffMonths < 2){
        status = "Probation";
      }
      else if(diffMonths === 2){
        status = "⚠ APPLY THIS MONTH";
      }
      else{
        status = "❗ OVERDUE";
      }

      output.push([
        id,
        name,
        joinDate,
        diffMonths,
        pf,
        esi,
        status
      ]);
    }

    if (output.length <= 1) {
      throw new Error("No valid employees for tracker");
    }

    // ==============================
    // 🔽 SORT PRIORITY
    // ==============================
    const priority = {
      "❗ OVERDUE": 1,
      "⚠ APPLY THIS MONTH": 2,
      "Probation": 3,
      "Completed": 4
    };

    const body = output.slice(1).sort((a,b)=>{
      return priority[a[6]] - priority[b[6]];
    });

    const finalData = [output[0], ...body];

    // ==============================
    // 📥 WRITE
    // ==============================
    tracker.getRange(1,1,finalData.length,finalData[0].length)
      .setValues(finalData);

    // ==============================
    // 🎨 FORMAT
    // ==============================
    tracker.setFrozenRows(1);

    tracker.getRange("A1:G1")
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    tracker.getRange(2,3,finalData.length,1)
      .setNumberFormat("dd-mmm-yyyy");

    tracker.autoResizeColumns(1,7);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PF_ESI_TRACKER_UPDATED",
      "Tracker Refreshed",
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("PF & ESI Tracker updated", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}