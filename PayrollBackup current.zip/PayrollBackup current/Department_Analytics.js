// ==============================
// 🧠 DEPARTMENT ANALYTICS (FINAL)
// ==============================
function generateDepartmentAnalytics() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getActiveSheet();

    const sheetName = sheet.getName();

    // ==============================
    // 🛡️ VALIDATION
    // ==============================
    if (!isPayrollSheet(sheetName)) {
      throw new Error("Not a payroll sheet");
    }

    if (sheet.getRange("Z1").getValue() !== "FINALIZED") {
      throw new Error("Finalize payroll before analytics");
    }

    let analytics = ss.getSheetByName("DEPARTMENT_ANALYTICS");

    if (!analytics) {
      analytics = ss.insertSheet("DEPARTMENT_ANALYTICS");
    }

    const lastRow = sheet.getLastRow();
    if (lastRow < 3) throw new Error("No payroll data");

    const totalCols = sheet.getLastColumn();

    const data = sheet
      .getRange(3,1,lastRow-2,totalCols)
      .getValues();

    const c = CONFIG.COLUMNS;

    const deptTotals = {};

    // ==============================
    // 📊 PROCESS
    // ==============================
    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];
      if (!empId) return;

      const department = row[c.DEPARTMENT - 1];
      const netSalary = Number(row[c.NET - 1]) || 0;

      if (!department || netSalary <= 0) return;

      if (!deptTotals[department]) {
        deptTotals[department] = 0;
      }

      deptTotals[department] += netSalary;

    });

    if (Object.keys(deptTotals).length === 0) {
      throw new Error("No valid department data");
    }

    // ==============================
    // 🔽 SORT DATA
    // ==============================
    const sortedData = Object.entries(deptTotals)
      .map(([dept, total]) => [dept, total])
      .sort((a,b) => b[1] - a[1]);

    // ==============================
    // 🧹 CLEAR
    // ==============================
    analytics.getRange(1,1,100,10).clearContent().clearFormat();

    // ==============================
    // 📊 HEADER
    // ==============================
    analytics.getRange(1,1,1,2).setValues([
      ["Department","Total Salary"]
    ]);

    analytics.getRange(1,1,1,2)
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    // ==============================
    // 📥 DATA
    // ==============================
    analytics.getRange(2,1,sortedData.length,2)
      .setValues(sortedData);

    // ==============================
    // 💰 FORMAT
    // ==============================
    analytics.getRange(2,2,sortedData.length,1)
      .setNumberFormat("₹ #,##0");

    analytics.setFrozenRows(1);

    // Alignment
    analytics.getRange(2,1,sortedData.length,1)
      .setHorizontalAlignment("left");

    analytics.getRange(2,2,sortedData.length,1)
      .setHorizontalAlignment("right");

    // ==============================
    // 📊 CHART (CLEAN)
    // ==============================
    const charts = analytics.getCharts();
    charts.forEach(chart => analytics.removeChart(chart));

    const chart = analytics.newChart()
      .setChartType(Charts.ChartType.PIE)
      .addRange(analytics.getRange(1,1,sortedData.length+1,2))
      .setPosition(2,4,0,0)
      .setOption("title", "Department Salary Distribution")
      .build();

    analytics.insertChart(chart);

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "DEPARTMENT_ANALYTICS_GENERATED",
      sheetName,
      Session.getEffectiveUser().getEmail()
    );

    SpreadsheetApp.getActiveSpreadsheet()
      .toast("Department analytics generated", "Success", 3);

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}