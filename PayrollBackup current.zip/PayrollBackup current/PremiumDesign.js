function applyPremiumDesign(sheet) {

  try {

    if (!sheet) throw new Error("Sheet missing");

    const lastRow = sheet.getLastRow();
    const lastCol = sheet.getLastColumn();

    if (lastRow < 2 || lastCol === 0) return;

    const sheetName = sheet.getName();
    const isPayroll = isPayrollSheet(sheetName);

    const c = CONFIG.COLUMNS || {};
    const colors = CONFIG.COLORS || {};

    const headerRow = isPayroll ? 2 : 1;
    const dataStart = headerRow + 1;

    if (lastRow < dataStart) return;

    const dataRange = sheet.getRange(dataStart, 1, lastRow - headerRow, lastCol);
    const values = dataRange.getValues();

    const bgMatrix = [];

    // ==============================
    // 🔒 SAFE COLUMN VALIDATION
    // ==============================
    const safe = col => col && col > 0 && col <= lastCol;

    const inputCols = [
      c.PRESENT_DAYS,
      c.SALARY_DAYS,
      c.INCENTIVE,
      c.ADVANCE,
      c.HOSPITAL_DEDUCTION,
      c.PENALTY,
      c.LEAVE_DEDUCTION,
      c.REMARKS
    ].filter(safe);

    const calcCols = [
      c.PER_DAY,
      c.GROSS,
      c.NET,
      c.TOTAL_DEDUCTION
    ].filter(safe);

    for (let i = 0; i < values.length; i++) {

      const row = values[i];
      const rowColors = new Array(lastCol);

      const baseColor = (i % 2 === 0) ? "#ffffff" : "#f7faff";

      for (let j = 0; j < lastCol; j++) {
        rowColors[j] = baseColor;
      }

      if (isPayroll) {

        const empId = row[c.EMP_ID - 1];

        // ==============================
        // 🟦 DEPARTMENT ROW
        // ==============================
        if (!empId) {

          for (let j = 0; j < lastCol; j++) {
            rowColors[j] = colors.DEPT_ROW || "#d9e1f2";
          }

          bgMatrix.push(rowColors);
          continue;
        }

        // ==============================
        // ✍️ INPUT
        // ==============================
        inputCols.forEach(col => {
          rowColors[col - 1] = colors.INPUT_BG || "#fff2cc";
        });

        // ==============================
        // 📊 CALC
        // ==============================
        calcCols.forEach(col => {
          rowColors[col - 1] = colors.CALC_BG || "#e6f3ff";
        });

        // ==============================
        // 💰 STATUS
        // ==============================
        const status = row[c.STATUS - 1];

        if (status === CONFIG.PAYMENT_STATUS.PAID) {
          rowColors[c.STATUS - 1] = colors.PAID || "#d9ead3";
        }
        else if (status === CONFIG.PAYMENT_STATUS.HOLD) {
          rowColors[c.STATUS - 1] = colors.HOLD || "#fce5cd";
        }
        else {
          rowColors[c.STATUS - 1] = colors.PENDING || "#f4cccc";
        }

      }

      bgMatrix.push(rowColors);
    }

    // ==============================
    // 🚀 SINGLE WRITE
    // ==============================
    dataRange.setBackgrounds(bgMatrix);

    // ==============================
    // 📏 SAFE BORDER (OPTIONAL)
    // ==============================
    // Only apply if needed (avoid override)
    // dataRange.setBorder(true,true,true,true,false,false);

    dataRange.setVerticalAlignment("middle");

  } catch (err) {

    Logger.log("Design Error: " + err.message);
    throw err;

  }

}