// ==============================
// 🏥 TOWN HOSPITALS - MASTER CONFIG (ELITE FINAL)
// ==============================

const CONFIG = Object.freeze({

  // ==============================
  // 📂 SHEET NAMES (LOCKED)
  // ==============================
  SHEETS: {
    EMPLOYEE_MASTER: "EMPLOYEE_MASTER",
    EMPLOYEE_DETAILS: "EMPLOYEE_DETAILS",
    DEPARTMENT_ORDER: "DEPARTMENT_ORDER",
    DESIGNATION_MAP: "DESIGNATION_MAP",
    PAYROLL_TEMPLATE: "PAYROLL_TEMPLATE",
    PAYROLL_HISTORY: "PAYROLL_HISTORY",
    EMPLOYMENT_HISTORY: "EMPLOYMENT_HISTORY", // ✅ FIXED
    SYSTEM_LOG: "SYSTEM_LOG",
    HR_DASHBOARD: "HR_DASHBOARD",

    // ✅ SAFE FALLBACK (avoid crashes if used anywhere)
    IMPORT: "PETPOOJA_IMPORT"
  },

  // ==============================
  // 👑 ADMIN CONTROL (STRICT)
  // ==============================
  ADMINS: [
    "thrinadhreddy@hotmail.com",
    "thrinadhreddy999@gmail.com"
  ],

  // ==============================
  // 🧠 SYSTEM FLAGS
  // ==============================
  SYSTEM: {
    ALLOW_MANUAL_EDIT: false,
    DEBUG: true,
    LOG_LEVEL: "INFO", // DEBUG / INFO / ERROR
    MAX_ROWS: 5000
  },

  // ==============================
  // 👨‍⚕️ EMPLOYEE STATUS
  // ==============================
  STATUS: {
    ACTIVE: "Active",
    PROBATION: "Probation",
    RESIGNED: "Resigned",
    TERMINATED: "Terminated",
    ON_LEAVE: "On Leave",
    TEMP_BREAK: "Temporary Break",
    CONTRACT_COMPLETED: "Contract Completed",
    ABSCONDED: "Absconded"
  },

  // ==============================
  // 💰 PAYMENT STATUS
  // ==============================
  PAYMENT_STATUS: {
    PENDING: "Pending",
    PAID: "Paid",
    HOLD: "Hold"
  },

  // ==============================
  // 🧾 DEFAULT VALUES
  // ==============================
  DEFAULTS: {
    EMPLOYMENT_TYPE: "Full-Time",
    SALARY_TYPE: "Monthly",
    ROW_COLOR: "#ffffff"
  },

  // ==============================
  // 💱 SYSTEM FINANCE
  // ==============================
  FINANCE: {
    CURRENCY: "₹",
    LOCALE: "en-IN"
  },

  // ==============================
  // 📅 DATE STANDARD
  // ==============================
  DATE: {
    FORMAT: "dd-MMM-yyyy"
  },

  // ==============================
  // 📊 PAYROLL COLUMN INDEXES
  // ⚠️ Used only for payroll sheets (fixed structure)
  // ==============================
  COLUMNS: {
    EMP_ID: 1,
    NAME: 2,
    DEPARTMENT: 3,
    MONTHLY_SALARY: 4,
    PER_DAY: 5,
    PRESENT_DAYS: 6,
    SALARY_DAYS: 7,
    INCENTIVE: 8,
    ADVANCE: 9,
    HOSPITAL_DEDUCTION: 10,
    PENALTY: 11,
    LEAVE_DEDUCTION: 12,
    PF: 13,
    ESI: 14,
    PT: 15,
    GROSS: 16,
    TOTAL_DEDUCTION: 17,
    NET: 18,
    STATUS: 19,
    REMARKS: 20
  },

  // ==============================
  // 📋 MASTER SHEET COLUMNS (DYNAMIC)
  // ==============================
  MASTER_COLUMNS: {
    EMP_ID: "Employee ID",
    FIRST_NAME: "First Name",
    LAST_NAME: "Last Name",
    DEPARTMENT: "Department",
    DESIGNATION: "Designation",
    EMP_TYPE: "Employment Type",
    SALARY: "Monthly Salary",
    SALARY_TYPE: "Salary Type",
    DOJ: "Date of Joining",
    PROBATION: "Probation End Date",
    STATUS: "Status",
    LEFT_DATE: "Left Date",
    UNIFORM_AMOUNT: "Uniform Deduction Amount",
    UNIFORM_MONTH: "Uniform Deduction Month",
    NOTES: "Notes"
  },

  // ==============================
  // 📋 DETAILS SHEET COLUMNS
  // ==============================
  DETAILS_COLUMNS: {
    EMP_ID: "Employee ID",
    NAME: "Display Name",
    MOBILE: "Mobile Number",
    EMAIL: "Email",
    STATUS: "Status",
    GENDER: "Gender",
    DOB: "Date of Birth",
    BANK: "Bank Name",
    IFSC: "IFSC Code",
    BRANCH: "Bank Branch",
    ACCOUNT: "Account Number",
    AADHAAR: "Aadhaar Number",
    PF: "PF Number",
    UAN: "UAN Number",
    ESI: "ESI Number",
    EMERGENCY_MOBILE: "Emergency Mobile",
    EMERGENCY_NAME: "Emergency Contact Name",
    EMERGENCY_RELATION: "Emergency Relation",
    EMERGENCY_ADDRESS: "Emergency Address",
    PERMANENT_ADDRESS: "Permanent Address",
    REF_NAME_1: "Reference Name 1",
    REF_NO_1: "Reference Number 1",
    REF_NAME_2: "Reference Name 2",
    REF_NO_2: "Reference Number 2",
    AADHAAR_ATTACHED: "Aadhaar Attached",
    PAN_ATTACHED: "PAN Attached",
    DL_ATTACHED: "Driving Licence Attached",
    PHOTO_ATTACHED: "Photo Attached"
  },

  // ==============================
  // 🎨 DESIGN SYSTEM
  // ==============================
  COLORS: {
    HEADER_BG: "#1f3a5f",
    HEADER_TEXT: "#ffffff",

    EMPLOYEE_BG: "#e3f2fd",
    INPUT_BG: "#fff8e1",
    CALC_BG: "#e8f5e9",
    STATUS_BG: "#f3e5f5",

    PAID: "#d9ead3",
    HOLD: "#fce5cd",
    PENDING: "#eeeeee",

    INACTIVE_ROW: "#e0e0e0",
    DEPT_ROW: "#d6e4f0"
  },

  // ==============================
  // ✅ VALIDATIONS
  // ==============================
  VALIDATION: {
    PAYMENT_STATUS: ["Pending", "Paid", "Hold"]
  }

});


// ==============================
// 🔐 ADMIN CHECK
// ==============================
function isAdmin() {

  try {
    const user = Session.getEffectiveUser().getEmail();
    return !!user && CONFIG.ADMINS.includes(user);
  } catch (err) {
    Logger.log("Admin check error: " + err.message);
    return false;
  }

}


// ==============================
// 🚫 REQUIRE ADMIN
// ==============================
function requireAdminAccess() {

  if (!isAdmin()) {
    throw new Error("⛔ Admin access required");
  }

}