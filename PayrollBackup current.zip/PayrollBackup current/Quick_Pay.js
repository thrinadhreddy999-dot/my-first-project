// ==============================
// 💰 QUICK PAYMENT ENGINE (FINAL)
// ==============================

// ==============================
// 🎯 MAIN ENGINE
// ==============================
function updatePaymentStatus(statusValue) {

  try {

    const sheet = SpreadsheetApp.getActiveSheet();
    const sheetName = sheet.getName();
    const c = CONFIG.COLUMNS;
    const colors = CONFIG.COLORS;

    // ==============================
    // 🛡️ VALIDATIONS
    // ==============================
    if (!isPayrollSheet(sheetName)) {
      SpreadsheetApp.getActiveSpreadsheet()
        .toast("Not a payroll sheet", "Error", 2);
      return;
    }

    if (!CONFIG.VALIDATION.PAYMENT_STATUS.includes(statusValue)) {
      throw new Error("Invalid payment status");
    }

    // ==============================
    // 🔒 FINALIZED CHECK
    // ==============================
    if (sheet.getRange("Z1").getValue() === "FINALIZED") {
      SpreadsheetApp.getActiveSpreadsheet()
        .toast("Payroll finalized. Cannot modify.", "Locked", 3);
      return;
    }

    const range = sheet.getActiveRange();
    if (!range) {
      SpreadsheetApp.getActiveSpreadsheet()
        .toast("No selection", "Error", 2);
      return;
    }

    const startRow = range.getRow();
    const numRows = range.getNumRows();

    if (startRow < 3) {
      SpreadsheetApp.getActiveSpreadsheet()
        .toast("Invalid selection", "Error", 2);
      return;
    }

    // ==============================
    // 📊 READ REQUIRED COLUMN ONLY
    // ==============================
    const empIds = sheet
      .getRange(startRow, c.EMP_ID, numRows, 1)
      .getValues();

    const updates = [];
    const bgUpdates = [];

    let updated = 0;
    let skipped = 0;

    let color = colors.PENDING;

    if (statusValue === CONFIG.PAYMENT_STATUS.PAID) color = colors.PAID;
    if (statusValue === CONFIG.PAYMENT_STATUS.HOLD) color = colors.HOLD;

    for (let i = 0; i < numRows; i++) {

      const empId = empIds[i][0];

      if (!empId) {
        updates.push([null]);
        bgUpdates.push([null]);
        skipped++;
        continue;
      }

      updates.push([statusValue]);
      bgUpdates.push([color]);
      updated++;
    }

    // ==============================
    // 💾 WRITE (BATCH)
    // ==============================
    sheet.getRange(startRow, c.STATUS, updates.length, 1).setValues(updates);
    sheet.getRange(startRow, c.STATUS, bgUpdates.length, 1).setBackgrounds(bgUpdates);

    // ==============================
    // 📊 UPDATE SYSTEM
    // ==============================
    updatePayrollSummary(sheet);
    updatePaymentDashboard();

    // ==============================
    // 📜 LOG
    // ==============================
    logAction(
      "PAYMENT_UPDATE",
      `${statusValue} | Updated: ${updated} | Skipped: ${skipped}`,
      Session.getEffectiveUser().getEmail()
    );

    // ==============================
    // 🔔 FEEDBACK
    // ==============================
    SpreadsheetApp.getActiveSpreadsheet().toast(
      `${statusValue}: ${updated} updated | ${skipped} skipped`,
      "Payment Update",
      3
    );

  } catch (err) {

    SpreadsheetApp.getUi().alert("❌ " + err.message);

  }

}


// ==============================
// ✅ MARK AS PAID
// ==============================
function markSelectedAsPaid() {
  updatePaymentStatus(CONFIG.PAYMENT_STATUS.PAID);
}


// ==============================
// ⏸ MARK AS HOLD
// ==============================
function markSelectedAsHold() {
  updatePaymentStatus(CONFIG.PAYMENT_STATUS.HOLD);
}