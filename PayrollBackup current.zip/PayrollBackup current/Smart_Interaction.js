// ==============================
// 🧠 SMART INTERACTION ENGINE (ENTERPRISE FINAL)
// ==============================
function onEdit(e) {

  try {

    if (!e || !e.range) return;

    const sheet = e.source.getActiveSheet();
    const sheetName = sheet.getName();
    const row = e.range.getRow();
    const col = e.range.getColumn();

    const c = CONFIG.COLUMNS;
    const colors = CONFIG.COLORS;

    // ==============================
    // 🚫 IGNORE HEADER
    // ==============================
    if (row < 2) return;

    // ==============================
    // 🔒 SYSTEM LOCK (FUTURE CONTROL)
    // ==============================
    if (CONFIG.SYSTEM && CONFIG.SYSTEM.ALLOW_MANUAL_EDIT === false) {
      // Allow system-driven edits only (skip blocking for now)
    }

    // ==============================
    // 👨‍⚕️ EMPLOYEE MASTER
    // ==============================
    if (sheetName === CONFIG.SHEETS.EMPLOYEE_MASTER) {

      const statusCol = getColumnIndex(sheet, CONFIG.MASTER_COLUMNS.STATUS);
      const currentStatus = sheet.getRange(row, statusCol).getValue();

      // 🔒 LOCK INACTIVE
      if (
        !isAdmin() &&
        currentStatus &&
        currentStatus !== CONFIG.STATUS.ACTIVE &&
        currentStatus !== CONFIG.STATUS.PROBATION
      ) {
        e.range.setValue(e.oldValue || "");
        SpreadsheetApp.getActiveSpreadsheet()
          .toast("Inactive employee is locked", "Access Denied", 2);
        return;
      }

      // 🎨 ROW STYLING
      if (col === statusCol) {

        const newStatus = e.range.getValue();
        const lastCol = sheet.getLastColumn();

        const isInactive =
          newStatus &&
          newStatus !== CONFIG.STATUS.ACTIVE &&
          newStatus !== CONFIG.STATUS.PROBATION;

        sheet.getRange(row, 1, 1, lastCol)
          .setBackground(
            isInactive
              ? CONFIG.COLORS.INACTIVE_ROW
              : "#ffffff"
          );
      }

      // 🔁 AUTOMATION
      employeeAutomation(e);

      // 📊 DASHBOARD UPDATE (LIMITED)
      if (col === statusCol) {
        updateHRDashboard();
      }

      return;
    }

    // ==============================
    // ❌ NOT PAYROLL → STOP
    // ==============================
    if (!isPayrollSheet(sheetName)) return;

    if (row < 3) return;

    // ==============================
    // 📅 SAFE MONTH PARSE
    // ==============================
    const parts = sheetName.split(" ");
    if (parts.length < 2) return;

    const parsed = new Date(Date.parse(parts[0] + " 1, " + parts[1]));
    if (isNaN(parsed)) return;

    const daysInMonth = new Date(
      parsed.getFullYear(),
      parsed.getMonth() + 1,
      0
    ).getDate();

    // ==============================
    // 📆 PRESENT DAYS CONTROL
    // ==============================
    if (col === c.PRESENT_DAYS) {

      let presentDays = Number(e.range.getValue()) || 0;

      if (presentDays > daysInMonth) {
        presentDays = daysInMonth;
        e.range.setValue(presentDays);
      }

      sheet.getRange(row, c.SALARY_DAYS).setValue(presentDays);

      e.range.setBackground(colors.INPUT_BG);
    }

    // ==============================
    // ✍️ INPUT GROUP
    // ==============================
    const inputCols = [
      c.SALARY_DAYS,
      c.INCENTIVE,
      c.ADVANCE,
      c.HOSPITAL_DEDUCTION,
      c.PENALTY,
      c.LEAVE_DEDUCTION,
      c.REMARKS
    ];

    if (inputCols.includes(col)) {
      e.range.setBackground(colors.INPUT_BG);
    }

    // ==============================
    // 💰 STATUS COLOR
    // ==============================
    if (col === c.STATUS) {

      const status = e.range.getValue();

      let color = colors.PENDING;

      if (status === CONFIG.PAYMENT_STATUS.PAID) color = colors.PAID;
      else if (status === CONFIG.PAYMENT_STATUS.HOLD) color = colors.HOLD;

      e.range.setBackground(color);
    }

    // ==============================
    // 📊 SMART TRIGGERS
    // ==============================
    const triggerCols = [
      c.STATUS,
      c.PRESENT_DAYS,
      c.INCENTIVE,
      c.ADVANCE,
      c.HOSPITAL_DEDUCTION,
      c.PENALTY,
      c.LEAVE_DEDUCTION
    ];

    if (triggerCols.includes(col)) {

      updatePayrollSummary(sheet);

      if (col === c.STATUS) {
        updatePaymentDashboard();
      }
    }

  } catch (err) {

    Logger.log("Smart Interaction Error: " + err.message);

  }

}