// ==============================
// 💰 PAYROLL CALCULATION ENGINE (FINAL)
// ==============================
function calculatePayroll() {

  try {

    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const sheet = ss.getActiveSheet();
    const ui = SpreadsheetApp.getUi();

    const c = CONFIG.COLUMNS;

    // ==============================
    // 🛡️ VALID SHEET CHECK
    // ==============================
    if (!isPayrollSheet(sheet.getName())) {
      throw new Error("This is not a payroll sheet.");
    }

    // ==============================
    // 🔒 FINALIZED CHECK
    // ==============================
    if (sheet.getRange("Z1").getValue() === "FINALIZED") {
      ui.alert("Payroll already finalized. Cannot recalculate.");
      return;
    }

    // ==============================
    // 🛡️ SAFETY CHECK
    // ==============================
    payrollSafetyCheck();

    const lastRow = sheet.getLastRow();
    if (lastRow < 3) return;

    // ==============================
    // 📅 MONTH PARSE SAFE
    // ==============================
    const parts = sheet.getName().split(" ");
    if (parts.length < 2) {
      throw new Error("Invalid payroll sheet name.");
    }

    const parsed = new Date(Date.parse(parts[0] + " 1, " + parts[1]));
    if (isNaN(parsed)) {
      throw new Error("Invalid month format in sheet name.");
    }

    const daysInMonth = new Date(
      parsed.getFullYear(),
      parsed.getMonth() + 1,
      0
    ).getDate();

    // ==============================
    // 📊 READ DATA
    // ==============================
    const totalCols = sheet.getLastColumn();
    const data = sheet.getRange(3,1,lastRow-2,totalCols).getValues();

    const output = [];

    let totalEmployees = 0;
    let totalGross = 0;
    let totalDeduction = 0;
    let totalNet = 0;
    let totalPaid = 0;

    data.forEach(row => {

      const empId = row[c.EMP_ID - 1];

      // ==============================
      // SKIP DEPARTMENT ROW
      // ==============================
      if (!empId) {
        output.push(new Array(8).fill(""));
        return;
      }

      let monthlySalary = Math.max(0, Number(row[c.MONTHLY_SALARY - 1]) || 0);
      let presentDays = Math.max(0, Number(row[c.PRESENT_DAYS - 1]) || 0);

      if (presentDays > daysInMonth) {
        presentDays = daysInMonth;
      }

      if (!monthlySalary) {
        output.push(new Array(8).fill(""));
        return;
      }

      totalEmployees++;

      // ==============================
      // 💰 CORE CALCULATION
      // ==============================
      const perDay = monthlySalary / daysInMonth;
      const salaryDays = presentDays;

      const gross = Math.round(perDay * salaryDays);

      const incentive = Number(row[c.INCENTIVE - 1]) || 0;
      const advance = Number(row[c.ADVANCE - 1]) || 0;
      const hospitalDed = Number(row[c.HOSPITAL_DEDUCTION - 1]) || 0;
      const penalty = Number(row[c.PENALTY - 1]) || 0;
      const leaveDed = Number(row[c.LEAVE_DEDUCTION - 1]) || 0;

      // ==============================
      // 📊 STATUTORY (SIMPLIFIED)
      // ==============================
      const pf = monthlySalary <= 15000 ? Math.round(gross * 0.12) : 0;
      const esi = monthlySalary <= 21000 ? Math.round(gross * 0.0075) : 0;
      const pt = gross >= 15000 ? 200 : 0;

      const totalDed =
        pf + esi + pt + advance + hospitalDed + penalty + leaveDed;

      let net = Math.round(gross + incentive - totalDed);

      // ==============================
      // 🛡️ NEGATIVE PROTECTION
      // ==============================
      if (net < 0) net = 0;

      // ==============================
      // 📊 SUMMARY
      // ==============================
      totalGross += gross;
      totalDeduction += totalDed;
      totalNet += net;

      if (row[c.STATUS - 1] === CONFIG.PAYMENT_STATUS.PAID) {
        totalPaid += net;
      }

      output.push([
        Math.round(perDay),
        salaryDays,
        gross,
        pf,
        esi,
        pt,
        totalDed,
        net
      ]);

    });

    // ==============================
    // 📥 WRITE OUTPUT
    // ==============================
    sheet.getRange(3, c.PER_DAY, output.length, 8).setValues(output);

    const remaining = totalNet - totalPaid;

    // ==============================
    // 📊 SUMMARY PANEL
    // ==============================
    const col = totalCols + 2;

    const summary = [
      ["PAYROLL SUMMARY", ""],
      ["Employees", totalEmployees],
      ["Total Gross", totalGross],
      ["Total Deduction", totalDeduction],
      ["Total Net", totalNet],
      ["Paid", totalPaid],
      ["Remaining", remaining]
    ];

    sheet.getRange(1, col, summary.length, 2).setValues(summary);

    // ==============================
    // 🎨 STYLE
    // ==============================
    sheet.getRange(1, col, 1, 2)
      .setFontWeight("bold")
      .setBackground(CONFIG.COLORS.HEADER_BG)
      .setFontColor(CONFIG.COLORS.HEADER_TEXT)
      .setHorizontalAlignment("center");

    sheet.getRange(2, col, summary.length-1, 2)
      .setBackground("#f9f9f9");

    // Currency formatting
    sheet.getRange(3, c.GROSS, output.length, 1).setNumberFormat("₹ #,##0");
    sheet.getRange(3, c.NET, output.length, 1).setNumberFormat("₹ #,##0");

  } catch (err) {

    SpreadsheetApp.getUi().alert("Payroll Error: " + err.message);
    throw err;

  }

}